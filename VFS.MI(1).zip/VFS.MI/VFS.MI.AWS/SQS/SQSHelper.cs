﻿using Amazon.SQS.Model;
using Amazon.SQS;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VFS.MI.AWS.SQS
{
    public class SQSHelper: ISQSHelper
    {
        private IAmazonSQS _sqsClient;

        public SQSHelper(IAmazonSQS sqsClient)
        {
            this._sqsClient = sqsClient;
           
        }

        public  async Task<SendMessageResponse> SendMessage( string qUrl, string messageBody)
        {
            try
            {
                SendMessageRequest sendMessageRequest = new SendMessageRequest();
                sendMessageRequest.MessageBody = messageBody;
                sendMessageRequest.MessageGroupId = "default-group";
                sendMessageRequest.QueueUrl= qUrl;
                sendMessageRequest.MessageDeduplicationId= Guid.NewGuid().ToString();
                return await _sqsClient.SendMessageAsync(sendMessageRequest);

            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public async Task<DeleteMessageResponse> DeleteMessage(string qUrl, string reciptHandle,CancellationToken cancellationToken)
        {
            try
            {
                return await _sqsClient.DeleteMessageAsync(qUrl, reciptHandle, cancellationToken);

            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public  async Task<ReceiveMessageResponse> GetMessage(string qUrl, int waitTime = 0)
        {
            return await _sqsClient.ReceiveMessageAsync(new ReceiveMessageRequest
            {
                QueueUrl = qUrl,
                MaxNumberOfMessages = 10,
                WaitTimeSeconds = waitTime
                // (Could also request attributes, set visibility timeout, etc.)
            });
        }
    }
}
