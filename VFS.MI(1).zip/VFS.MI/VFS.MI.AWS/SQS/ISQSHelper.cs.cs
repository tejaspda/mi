﻿using Amazon.SQS.Model;
using Amazon.SQS;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VFS.MI.AWS.SQS
{
    public interface ISQSHelper
    {
        Task<SendMessageResponse> SendMessage(string qUrl, string messageBody);
        Task<ReceiveMessageResponse> GetMessage(string qUrl, int waitTime = 0);
        Task<DeleteMessageResponse> DeleteMessage(string qUrl, string messageBody, CancellationToken cancellationToken);

    }
}
