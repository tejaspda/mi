﻿using Amazon.S3.Model;
using Amazon.S3;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VFS.MI.AWS.S3
{
    public  interface IS3Helper
    {
        public string GeneratePresignedURL(string bucket, string key);
        public string GeneratePresignedURLDownload(string bucket, string key);
        public Task<bool> DeleteObjectAsync(string bucket, string key);
        public List<String> GetListObject(string bucket, string key);
        public Task<bool> UploadFile(string bucket, string key, string encryptedFilPath);
    }
}
