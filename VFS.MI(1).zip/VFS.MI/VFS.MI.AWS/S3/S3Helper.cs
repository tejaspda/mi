﻿using Amazon.S3.Model;
using Amazon.S3;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime;

namespace VFS.MI.AWS.S3
{
    public class S3Helper : IS3Helper
    {
        private IAmazonS3 _amazonS3;
        public S3Helper(IAmazonS3 amazonS3)
        {
            _amazonS3 = amazonS3;
        }
        public string GeneratePresignedURL(string bucket,string key)
        {
            try
            {
                var request = new GetPreSignedUrlRequest
                {
                    BucketName = bucket,
                    Key = key,
                    Verb = HttpVerb.PUT,
                    Expires = DateTime.Now.AddMinutes(5)
                };
                string url = _amazonS3.GetPreSignedURL(request);
                return url;
            }
            catch (AmazonS3Exception e)
            {
                // _ilog.Error(e.Message);
                //_ilog.Error(e.StackTrace);
                throw e;
            }
            catch (Exception e)
            {
                //_ilog.Error(e.Message);
                //_ilog.Error(e.StackTrace);
                throw;
            }

        }
        public string GeneratePresignedURLDownload(string bucket, string key)
        {
            try
            {
                var request = new GetPreSignedUrlRequest
                {
                    BucketName = bucket,
                    Key = key,
                    Verb = HttpVerb.GET,
                    Expires = DateTime.Now.AddMinutes(5)
                };
                string url = _amazonS3.GetPreSignedURL(request);
                return url;
            }
            catch (AmazonS3Exception e)
            {
                // _ilog.Error(e.Message);
                //_ilog.Error(e.StackTrace);
                throw e;
            }
            catch (Exception e)
            {
                //_ilog.Error(e.Message);
                //_ilog.Error(e.StackTrace);

                throw e;

            }
        }
        public async Task<bool> DeleteObjectAsync(string bucket, string key)
        {
            try
            {
                var deleteObjectRequest = new DeleteObjectRequest
                {
                    BucketName = bucket,
                    Key = key
                };
                DeleteObjectResponse deleteObjectResponse =await _amazonS3.DeleteObjectAsync(deleteObjectRequest);
                if (deleteObjectResponse.HttpStatusCode == System.Net.HttpStatusCode.OK)
                {
                    return true;
                }
                else {
                    return false;
                }
            }
            catch (AmazonS3Exception e)
            {
                return false;
            }
            catch (Exception e)
            {
                return false;
            }
        }
        public  List<String> GetListObject(string bucket, string key)
        {
            try
            {
                List<String> uploadedFiles = new List<String>();

                ListObjectsRequest getListObjectRequest = new ListObjectsRequest
                {
                    BucketName = bucket,
                    Prefix = key
                };
                ListObjectsResponse listObjectsResponse =  _amazonS3.ListObjectsAsync(getListObjectRequest).Result;
                for (int i = 0; i < listObjectsResponse.S3Objects.Count; i++)
                {
                    uploadedFiles.Add(listObjectsResponse.S3Objects[i].Key);
                }
                return uploadedFiles;
            }
            catch (AmazonS3Exception e)
            {
                // _ilog.Error(e.Message);
                // _ilog.Error(e.StackTrace);
                throw e;
            }
            catch (Exception e)
            {
                //  _ilog.Error(e.Message);
                //_ilog.Error(e.StackTrace);
                throw e;
            }
        }
        public async Task<bool> UploadFile(string bucket, string key, string encryptedFilPath)
        {
            try
            {
                PutObjectRequest request = new PutObjectRequest()
                {
                    FilePath = encryptedFilPath,
                    BucketName = bucket,
                    Key = key
                };
                PutObjectResponse response = await _amazonS3.PutObjectAsync(request);
                if (response.HttpStatusCode == System.Net.HttpStatusCode.OK)
                    return true;
                else
                    return false;
            }
            catch (Exception ex)
            {

                throw;
            }
        }


    }
}
