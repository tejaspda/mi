﻿using System.Threading.Tasks.Dataflow;
using VFS.MI.AWS.S3;
using VFS.MI.Main.Contract.V1.Requests;
using VFS.MI.Main.DAL;

namespace VFS.MI.Main.Business
{
    public class MiMainBusiness
    {
        private IS3Helper _iS3Helper;
        private IMIMainDAL _mIMainDAL;

        public MiMainBusiness(IS3Helper iS3Helper,IMIMainDAL mIMainDAL )
        {
            _iS3Helper = iS3Helper;
            _mIMainDAL = mIMainDAL;
        }

        internal string getPresignedURL(GetPreSignedURLRequest preSignedURLRequest)
        {
            if (String.IsNullOrEmpty(preSignedURLRequest.AURN))
            {
                return _iS3Helper.GeneratePresignedURLDownload("",
                    key: $"{preSignedURLRequest.MissionCode}/{preSignedURLRequest.CountryCode}/{preSignedURLRequest.VacCode}/{preSignedURLRequest.Date.Replace("-", "")}"
                    );
            }
            else {
                return _iS3Helper.GeneratePresignedURLDownload("mi-poland", _mIMainDAL.GetS3KeyForAurn(preSignedURLRequest.AURN));
            }
            
        }
    }
}
