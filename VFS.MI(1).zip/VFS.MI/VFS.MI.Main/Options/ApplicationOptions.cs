﻿namespace VFS.MI.Main.Options
{
    public class ApplicationOptions
    {
        public string? ConnectionString { get; set; }
    }
}
