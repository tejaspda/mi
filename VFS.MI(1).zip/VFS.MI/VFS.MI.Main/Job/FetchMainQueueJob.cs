﻿using Amazon.SQS.Model;
using Microsoft.Extensions.Options;
using System.Text.Json;
using System.Threading;
using VFS.Caching;
using VFS.MI.AWS.SQS;
using VFS.MI.Main.Contract.V1.SQS;
using VFS.MI.Main.DAL;
using VFS.MI.Main.Options;

namespace VFS.MI.Main.Job
{
    public class FetchMainQueueJob : BackgroundService
    {

        private ISQSHelper sqsHelper;
        private int pauseTimeMinute = 2;
        private IUtilitiesCache _utilitiesCache;
        private IMIMainDAL _mIMainDAL;
        private ApplicationOptions _applicationOptions;

        public FetchMainQueueJob(ISQSHelper sqsHelper, IUtilitiesCache utilitiesCache,IMIMainDAL mIMainDAL,IOptions<ApplicationOptions> applicationOptions)
        {
            this.sqsHelper = sqsHelper;
            _utilitiesCache = utilitiesCache;
            _mIMainDAL = mIMainDAL;
            _applicationOptions = applicationOptions.Value;
        }

        protected override Task ExecuteAsync(CancellationToken stoppingToken)
        {
            return Task.Factory.StartNew(async () =>
            {
                while (!stoppingToken.IsCancellationRequested)
                {
                    try
                    {
                        string mainQueueURL=_utilitiesCache.GetSqsUrl(_applicationOptions.ConnectionString, "MQ1", false);

                        ReceiveMessageResponse messageResponse=await sqsHelper.GetMessage(mainQueueURL, 0);
                        if (messageResponse.Messages.Any())
                        {
                            foreach (var message in messageResponse.Messages) {
                                BoltSqsData boltSqsData;
                                string queueURL;
                                if (!String.IsNullOrEmpty(message.Body)) {
                                 
                                    boltSqsData = JsonSerializer.Deserialize<BoltSqsData>(message.Body);                                  
                                    queueURL = _utilitiesCache.GetSqsUrl(_applicationOptions.ConnectionString, boltSqsData.MissionCode, false);                                  
                                    await sqsHelper.SendMessage(queueURL, message.Body);
                                    string s3Key = "";
                                    _mIMainDAL.InsertQueueData(boltSqsData.FormularNumber, boltSqsData.MissionCode, boltSqsData.CountryCode, boltSqsData.VacCode, s3Key, 0, 1);
                                    await sqsHelper.DeleteMessage(mainQueueURL, message.ReceiptHandle.ToString(), stoppingToken);
                                }
   



                            }

                            pauseTimeMinute = 2;
                            await Task.Delay(TimeSpan.FromMinutes(pauseTimeMinute), stoppingToken);
                        }
                        else {
                            pauseTimeMinute = pauseTimeMinute + 2;
                            if (pauseTimeMinute > 10) {
                                pauseTimeMinute = 10;
                            }
                            await Task.Delay(TimeSpan.FromMinutes(pauseTimeMinute), stoppingToken);
                        }
                        
                    }
                    catch (OperationCanceledException) {
                    
                    }
                }
            }, stoppingToken);
        }

        public override async Task StopAsync(CancellationToken cancellationToken)
        {
            await Task.CompletedTask;
        }
    }
}
