﻿using static VFS.MI.Main.DAL.MIMainDAL;
using System.Data;
using System.Data.SqlClient;
using Amazon.S3.Model;
using Microsoft.Extensions.Options;
using VFS.MI.Main.Options;

namespace VFS.MI.Main.DAL
{
    public class MIMainDAL : IMIMainDAL
    {
        private ApplicationOptions _applicationOptions;
        string conStr = String.Empty;

        public MIMainDAL(IOptions<ApplicationOptions> applicationOptions)
        {
            _applicationOptions = applicationOptions.Value;
            conStr = _applicationOptions.ConnectionString;
        }



        public string GetS3KeyForAurn(string Arn)
        {

            try
            {
                using (SqlConnection con = new SqlConnection(conStr))
                {
                    
                    SqlCommand cmd = new SqlCommand("proc_get_S3_key", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@ARN", Arn);

                    SqlParameter outputParam = cmd.Parameters.Add("@msgOutput", SqlDbType.NVarChar, 500);
                    outputParam.Direction = ParameterDirection.Output;
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataSet ds = new DataSet();
                    da.Fill(ds);

                    return ds.Tables[0].Rows[0]["S3Key"].ToString();
                    
                }
            }
            catch (Exception e)
            {
                throw;
            }
        }




        public string InsertQueueData(string arn,string missionCode, string countryCode,string vacCode, string S3Key, int isPriority,int sessionId)
        {

            try
            {
                using (SqlConnection con = new SqlConnection(conStr))
                {
                    SqlCommand cmd = new SqlCommand("proc_insert_queue_data", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@ARN", arn);
                    cmd.Parameters.AddWithValue("@MissionCode", missionCode);
                    cmd.Parameters.AddWithValue("@CountryCode", countryCode);
                    cmd.Parameters.AddWithValue("@VacCode", vacCode);
                    cmd.Parameters.AddWithValue("@S3Key", S3Key);
                    cmd.Parameters.AddWithValue("@IsPriority", isPriority);
                    cmd.Parameters.AddWithValue("@SessionId", sessionId);

                    SqlParameter outputParam = cmd.Parameters.Add("@msgOutput", SqlDbType.NVarChar, 500);
                    outputParam.Direction = ParameterDirection.Output;
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();

                    return outputParam.ToString();
                }
            }
            catch (Exception e)
            {
                throw;
            }
        }


    }
}
