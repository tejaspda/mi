﻿namespace VFS.MI.Main.DAL
{
    public interface IMIMainDAL
    {
        public string GetS3KeyForAurn(string Aurn);

        public string InsertQueueData(string arn, string missionCode, string countryCode, string vacCode,string S3Key, int isPriority, int sessionId);
    }
}
