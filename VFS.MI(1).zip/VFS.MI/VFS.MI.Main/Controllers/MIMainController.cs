using Microsoft.AspNetCore.Mvc;
using VFS.MI.Main.Business;
using VFS.MI.Main.Contract.V1;
using VFS.MI.Main.Contract.V1.Requests;
using VFS.MI.Main.Contract.V1.Response;

namespace VFS.MI.Main.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class MIMainController : Controller
    {

        private readonly ILogger<MIMainController> _logger;
        private MiMainBusiness _miMainBusiness;

        public MIMainController(ILogger<MIMainController> logger,MiMainBusiness miMainBusiness)
        {
            _logger = logger;
            _miMainBusiness = miMainBusiness;
        }

        [HttpPost(APIContract.MIMainEndPoints.GetPreSignedURL)]
        public IActionResult GetPreSignedURL(GetPreSignedURLRequest preSignedURLRequest)
        {

            var response = new GetPreSignedURLResponse();
            response.PreSignedURL = _miMainBusiness.getPresignedURL(preSignedURLRequest);
            response.RequestId = preSignedURLRequest.RequestId;
            response.ResponseCode = 200;
            response.ResponseMessage = "Success";


            return Ok (response);
        }


        [HttpPost(APIContract.MIMainEndPoints.UpdatePolandKey)]
        public IActionResult UpdatePolandKey(GetPreSignedURLRequest preSignedURLRequest)
        {
           
            var response = new GetPreSignedURLResponse();
            response.PreSignedURL = _miMainBusiness.getPresignedURL(preSignedURLRequest);
            response.RequestId = preSignedURLRequest.RequestId;
            response.ResponseCode = 200;
            response.ResponseMessage = "Success";


            return Ok(response);
        }
    }
}