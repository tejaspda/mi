﻿namespace VFS.MI.Main.Contract.V1.SQS
{
    public class BoltSqsData
    {
        public string? MissionCode { get; set; }
        public string? CountryCode { get; set; }
        public string? VacCode { get; set; }
        public string? FormularNumber { get; set; } 
        public string? date { get; set; }
    }
}
