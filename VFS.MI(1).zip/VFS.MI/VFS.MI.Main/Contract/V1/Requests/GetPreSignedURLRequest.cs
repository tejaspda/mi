﻿namespace VFS.MI.Main.Contract.V1.Requests
{
    public class GetPreSignedURLRequest
    {
        public string? RequestId { get; set; }
        public string? MissionCode { get; set; }
        public string? CountryCode { get; set; }
        public string? VacCode { get; set; }           
        public string? AURN { get; set; }
        public string? Date { get; set; }
        public int? SessionID { get; set; }
        
    }

}
