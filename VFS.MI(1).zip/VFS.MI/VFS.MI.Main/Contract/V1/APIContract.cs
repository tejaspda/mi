﻿namespace VFS.MI.Main.Contract.V1
{
    public class APIContract
    {
        public const string version = "v1";

        public class MIMainEndPoints {

            public const string GetPreSignedURL = version+ "/GetPreSignedURL";
            public const string UpdatePolandKey = version+ "/UpdatePolandKey";

        }
    }
}

