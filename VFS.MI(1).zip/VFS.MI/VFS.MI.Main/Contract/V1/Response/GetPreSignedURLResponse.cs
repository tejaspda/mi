﻿namespace VFS.MI.Main.Contract.V1.Response
{
    public class GetPreSignedURLResponse
    {
        public string? RequestId { get; set; }
        public string? ResponseMessage { get; set; }
        public int ResponseCode { get; set; }
        public string? PreSignedURL { get; set; }
        
    }
}
