using Amazon.Extensions.NETCore.Setup;
using Amazon.Runtime;
using Amazon.S3;
using Amazon.SQS;
using Microsoft.Extensions.Configuration;
using VFS.Caching;
using VFS.MI.AWS.S3;
using VFS.MI.AWS.SQS;
using VFS.MI.Main.Business;
using VFS.MI.Main.DAL;
using VFS.MI.Main.Job;
using VFS.MI.Main.Options;

internal class Program
{
    private static void Main(string[] args)
    {
        var builder = WebApplication.CreateBuilder(args);

      //  builder.AddLogger();



        /*        builder.WebHost.ConfigureAppConfiguration(
                                c => {

                                    c.AddSystemsManager(source => {
                                        source.Path = "/testapp";
                                        source.ReloadAfter =
                                            TimeSpan.FromMinutes(10);
                                    });
                                }
                            );*/

        // Add services to the container.

        builder.Services.AddControllers();
       
        // Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
        builder.Services.AddEndpointsApiExplorer();
        builder.Services.AddSwaggerGen();
        builder.Services.AddMemoryCache();


        builder.Services.AddAWSService<IAmazonSQS>();
        builder.Services.AddAWSService<IAmazonS3>();
        builder.Services.AddSingleton<ISQSHelper,SQSHelper>();
        builder.Services.AddSingleton<IS3Helper, S3Helper>();
        builder.Services.AddSingleton<MiMainBusiness>();
        builder.Services.AddSingleton<IMIMainDAL,MIMainDAL>();
        builder.Services.AddSingleton<ICtTablesCaching, CtTablesCaching>();
        builder.Services.AddSingleton<IUtilitiesCache, UtilitiesCache>();
        builder.Services.Configure<ApplicationOptions>(builder.Configuration.GetSection("ApplicationOptions"));




        //Main Queue Job
        builder.Services.AddHostedService<FetchMainQueueJob>();

        var app = builder.Build();

        // Configure the HTTP request pipeline.
        if (app.Environment.IsDevelopment())
        {
            app.UseSwagger();
            app.UseSwaggerUI();
        }

        app.UseHttpsRedirection();

        app.UseAuthorization();

        app.MapControllers();


        app.Run();
    }
}