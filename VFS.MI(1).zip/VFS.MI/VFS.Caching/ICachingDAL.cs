﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VFS.Caching
{
    internal interface ICachingDAL
    {
        public DataSet GetCtTablesDataFromDb(string conStr, string missionCode);
        public DataTable GetSqsUrl(string conStr);
        public DataTable GetBiometricUrl(string conStr);
    }
}
