﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VFS.Caching
{
    public interface ICtTablesCaching
    {
        public string GetCtParamValues(string conStr, string missionCode,string masterName, string inputParam, string outputParam);
    }
}
