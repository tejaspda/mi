﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VFS.Caching
{
    public interface IUtilitiesCache
    {
        public string GetSqsUrl(string conStr ,string missionCode, bool isPriority);
        public string GetBiometricUrl(string conStr, string missionCode, string countryCode);
    }
}
