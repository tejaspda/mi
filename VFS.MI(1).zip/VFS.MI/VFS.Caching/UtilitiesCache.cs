﻿using Microsoft.Extensions.Caching.Memory;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace VFS.Caching
{
    public class UtilitiesCache : IUtilitiesCache
    {
        private IMemoryCache _cache;

        public UtilitiesCache(IMemoryCache cache)
        {
            _cache = cache;
        }

        public string GetBiometricUrl(string conStr, string missionCode, string countryCode)
        {
            string biometricUrl = string.Empty;
            DataTable dtBiometricUrl;

            try
            {
                if (!_cache.TryGetValue("SqsQueueUrl", out dtBiometricUrl))
                {
                    ICachingDAL dal = new CachingDAL();
                    dtBiometricUrl = dal.GetBiometricUrl(conStr);
                    _cache.Set("SqsQueueUrl", dtBiometricUrl);
                }

                if (dtBiometricUrl != null)
                {
                    var result = from bioUrl in dtBiometricUrl.AsEnumerable()
                                 where bioUrl.Field<string>("MissionCode").Trim() == missionCode && bioUrl.Field<string>("CountryCode") == countryCode
                                 select new
                                 {
                                     biometricUrl = bioUrl.Field<string>("BioUrl")
                                 };
                    biometricUrl = result.ToList().Count > 0 ? result.FirstOrDefault().biometricUrl : string.Empty;
                }
            }
            catch (Exception e)
            {
                throw;
            }
            return biometricUrl;
        }

        public string GetSqsUrl(string conStr, string missionCode, bool isPriority)
        {
            string sqsQueueUrl = string.Empty;
            DataTable dtSqsQueueUrl;

            try
            {
                if (!_cache.TryGetValue("SqsQueueUrl", out dtSqsQueueUrl))
                {
                    ICachingDAL dal = new CachingDAL();
                    dtSqsQueueUrl = dal.GetSqsUrl(conStr);
                    _cache.Set("SqsQueueUrl", dtSqsQueueUrl);
                }

                if (dtSqsQueueUrl != null)
                {
                    var result = from sqsUrl in dtSqsQueueUrl.AsEnumerable()
                                 where sqsUrl.Field<string>("MissionCode").Trim() == missionCode
                                    && sqsUrl.Field<bool>("IsPriority") == isPriority
                                 select new
                                 {
                                     sqsQueueUrl = sqsUrl.Field<string>("QueueUrl")
                                 };
                    sqsQueueUrl = result.ToList().Count > 0 ? result.FirstOrDefault().sqsQueueUrl : string.Empty;
                }
            }
            catch (Exception e)
            {
                throw;
            }
            return sqsQueueUrl;
        }

    }
}


