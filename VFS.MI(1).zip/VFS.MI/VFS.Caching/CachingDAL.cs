﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VFS.Caching
{
    internal class CachingDAL : ICachingDAL
    {
        public DataSet GetCtTablesDataFromDb(string conStr, string missionCode)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(conStr))
                {
                    SqlCommand cmd = new SqlCommand("proc_get_ct_tables_data", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@MissionCode", missionCode);

                    SqlParameter outputParam = cmd.Parameters.Add("@msgOutput", SqlDbType.NVarChar, 500);
                    outputParam.Direction = ParameterDirection.Output;
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataSet ds = new DataSet();
                    da.Fill(ds);

                    for (int i = 0; i < ds.Tables.Count; i++)
                    {
                        ds.Tables[i].TableName = ds.Tables[i].Rows[0]["MasterName"].ToString();
                    }

                    return ds;
                }
            }
            catch (Exception e)
            {
                throw;
            }
        }

        public DataTable GetSqsUrl(string conStr)
        {
            DataTable dt = new DataTable();
            try
            {
                using (SqlConnection con = new SqlConnection(conStr))
                {
                    SqlCommand cmd = new SqlCommand("proc_get_sqs_url", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    SqlParameter outputParam = cmd.Parameters.Add("@msgOutput", SqlDbType.NVarChar, 500);
                    outputParam.Direction = ParameterDirection.Output;

                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    da.Fill(dt);
                }
            }
            catch (Exception e)
            {
                throw;
            }
            return dt;
        }

        public DataTable GetBiometricUrl(string conStr)
        {
            DataTable dt = new DataTable();
            try
            {
                using (SqlConnection con = new SqlConnection(conStr))
                {
                    SqlCommand cmd = new SqlCommand("proc_get_biometric_url", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    SqlParameter outputParam = cmd.Parameters.Add("@msgOutput", SqlDbType.NVarChar, 500);
                    outputParam.Direction = ParameterDirection.Output;

                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    da.Fill(dt);
                }
            }
            catch (Exception e)
            {
                throw;
            }
            return dt;
        }

    }
}
