﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Extensions.Caching.Memory;

namespace VFS.Caching
{
    public class CtTablesCaching : ICtTablesCaching
    {
        private IMemoryCache _cache;

        public CtTablesCaching(IMemoryCache cache)
        {
            _cache = cache;
        }

        public string GetCtParamValues(string conStr, string missionCode, string masterName, string inputParam, string outputParam)
        {
            string outputParamValue = string.Empty;
            try
            {
                DataSet ds = new DataSet();

                if (!_cache.TryGetValue("CtTables", out ds))
                {
                    ICachingDAL dal = new CachingDAL();
                    ds = dal.GetCtTablesDataFromDb(conStr,missionCode);
                    _cache.Set("CtTables", ds);
                }

                DataTable dtTmp = ds.Tables[masterName];

                if (dtTmp != null)
                {
                    var result = from row in dtTmp.AsEnumerable()
                                 where row.Field<string>("InputParamValue").Trim() == inputParam.Trim()
                                 && row.Field<string>("OutputParam").Trim() == outputParam.Trim()
                                 select new
                                 {
                                     outputParamValue = row.Field<string>("OutputParamValue").Trim()
                                 };

                    outputParamValue = result.ToList().Count > 0 ? result.FirstOrDefault().outputParamValue : string.Empty;
                }
            }
            catch (Exception e)
            {
                throw;
            }
            return outputParamValue;
        }

    }
}
