﻿namespace VFS.MI.Poland.Options
{
    public class ApplicationOptions
    {
        public string? ConnectionString { get; set; } 
    }
}
