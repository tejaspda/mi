﻿using VFS.MI.Poland.XMLGenerator.POCO;

namespace VFS.MI.Poland.Contract.V1.SQS
{
    public class BoltSqsData
    {
        public string MissionCode { get; set; }
        public string CountryCode { get; set; }
        public string VacCode { get; set; }
        public string FormularNumber { get; set; }
        public Applicant Applicant { get; set; }
        public ApplicationData ApplicationData { get; set; }

    }

    public class Address
    {
        public Country Country { get; set; }
        public string StateProvince { get; set; }
        public string Place { get; set; }
        public string PostalCode { get; set; }
        public string Addresss { get; set; }
    }

    public class Applicant
    {
        public string Surname { get; set; }
        public string SurnameAtBirth { get; set; }
        public string Name { get; set; }
        public string DateOfBirth { get; set; }
        public string PlaceOfBirth { get; set; }
        public string NationalIDNumber { get; set; }
        public CountryOfBirth CountryOfBirth { get; set; }
        public NationalityForApplication NationalityForApplication { get; set; }
        public NationalityAtBirth NationalityAtBirth { get; set; }
        public string Sex { get; set; }
        public string MaritalStatus { get; set; }
        public TravelDocument TravelDocument { get; set; }
        public string NameFather { get; set; }
        public string SurnameFather { get; set; }
        public NationalityFather NationalityFather { get; set; }
        public object AddressFather { get; set; }
        public string NameMother { get; set; }
        public string SurnameMother { get; set; }
        public NationalityMother NationalityMother { get; set; }
        public object AddressMother { get; set; }
        public Address Address { get; set; }
        public string PhoneAreaCode { get; set; }
        public string PhoneNumber { get; set; }
        public string Email { get; set; }
    }

    public class ApplicationData
    {
        public VisaType VisaType { get; set; }
        public string NumberOfEntries { get; set; }
        public int DurationOfStay { get; set; }
        public string DateOfArrival { get; set; }
        public string DateOfDeparture { get; set; }
        public Occupation Occupation { get; set; }
        public string OtherVisas { get; set; }
        public PurposesOfJourney PurposesOfJourney { get; set; }
        public Host Host { get; set; }
        public Cost Cost { get; set; }
        public InsurancePolicy InsurancePolicy { get; set; }
        public bool FingerprintsPrevCollected { get; set; }
        public DestinationCountries DestinationCountries { get; set; }
        public BorderOfFirstEntry BorderOfFirstEntry { get; set; }
    }

    public class BorderOfFirstEntry
    {
        public string Code_ICAO { get; set; }
    }

    public class Cost
    {
        public CostCoverage CostCoverage { get; set; }
        public MeansOfSupport MeansOfSupport { get; set; }
    }

    public class CostCoverage
    {
        public string Code { get; set; }
    }

    public class Country
    {
        public string Code_ICAO { get; set; }
    }

    public class CountryOfBirth
    {
        public string Code_ICAO { get; set; }
    }

    public class DestinationCountries
    {
        public string Code_ICAO { get; set; }
    }

    public class Host
    {
        public string PersonOrCompany { get; set; }
        public string SurnameName { get; set; }
        public Country Country { get; set; }
        public string Place { get; set; }
        public string Street { get; set; }
        public string PhoneNumber { get; set; }
    }

    public class InsurancePolicy
    {
        public string Surname { get; set; }
        public string ValidFrom { get; set; }
        public string ValidUntil { get; set; }
    }

    public class MeansOfSupport
    {
        public string Code { get; set; }
    }

    public class NationalityAtBirth
    {
        public string Code_ICAO { get; set; }
    }

    public class NationalityFather
    {
        public string Code_ICAO { get; set; }
    }

    public class NationalityForApplication
    {
        public string Code_ICAO { get; set; }
    }

    public class NationalityMother
    {
        public string Code_ICAO { get; set; }
    }

    public class Occupation
    {
        public string Code { get; set; }
    }

    public class PurposeOfJourney
    {
        public string Code { get; set; }
    }

    public class PurposesOfJourney
    {
        public PurposeOfJourney PurposeOfJourney { get; set; }
    }

    public class TravelDocument
    {
        public string Number { get; set; }
        public Type Type { get; set; }
        public string IssuingAuthority { get; set; }
        public string DateOfIssue { get; set; }
        public string ValidUntil { get; set; }
    }

    public class Type
    {
        public string Code { get; set; }
    }

    public class VisaType
    {
        public string Code { get; set; }
    }
}
