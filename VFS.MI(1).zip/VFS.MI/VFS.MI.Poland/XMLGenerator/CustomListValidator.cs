﻿
using System.ComponentModel.DataAnnotations;

using VFS.MI.Poland.XMLGenerator.POCO;

namespace VFS.MI.Poland.XMLGenerator
{
    public class CustomListValidator : ValidationAttribute
    {
        public override bool IsValid(object value)
        {
            if (value == null) { return false; }

            List<Log> log = (List<Log>)value;

            if (log.Count > 10)
            {
                return false;

            }
            else
            {
                return true;
            }

        }
    }
}
