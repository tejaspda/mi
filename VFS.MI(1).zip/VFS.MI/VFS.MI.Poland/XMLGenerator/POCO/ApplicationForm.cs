﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace VFS.MI.Poland.XMLGenerator.POCO
{

    public class ApplicationForm
    {
        public Applicant Applicant { get; set; }
        public ApplicationData ApplicationData { get; set; }
        public BiometricData BiometricData { get; set; }
    }

    public class Applicant
    {

        [StringLength(100, MinimumLength = 1)]
        public string Surname { get; set; }
        [StringLength(100, MinimumLength = 1)]
        public string SurnameAtBirth { get; set; }
        [Required]
        public string Name { get; set; }
        public string DateOfBirth { get; set; }
        public string PlaceOfBirth { get; set; }
        public string NationalIDNumber { get; set; }
        public CountryOfBirth CountryOfBirth { get; set; }
        public NationalityForApplication NationalityForApplication { get; set; }
        public NationalityAtBirth NationalityAtBirth { get; set; }
        public string Sex { get; set; }
        public string MaritalStatus { get; set; }
        public TravelDocument TravelDocument { get; set; }
        public string NameFather { get; set; }

        [StringLength(150, MinimumLength = 1)]
        public string SurnameFather { get; set; }
        public NationalityFather NationalityFather { get; set; }
        public AddressFather AddressFather { get; set; }
        public string NameMother { get; set; }

        [StringLength(150, MinimumLength = 1)]
        public string SurnameMother { get; set; }
        public NationalityMother NationalityMother { get; set; }
        public AddressMother AddressMother { get; set; }
        public Address Address { get; set; }
        [MaxLength(15)]
        public string PhoneAreaCode { get; set; }

        //[StringLength(30, MinimumLength = 1)]
        //[Range(0, 30)]
        public string PhoneNumber { get; set; }

    }

    public class ApplicationData
    {

        public VisaType VisaType { get; set; }

        [Required]
        [StringLength(2)]
        public string NumberOfEntries { get; set; }
        public int DurationOfStay { get; set; }
        public string DateOfArrival { get; set; }
        public string DateOfDeparture { get; set; }
        public Occupation Occupation { get; set; }
        [Required]
        [StringLength(10)]
        public string OtherVisas { get; set; }
        public PurposesOfJourney PurposesOfJourney { get; set; }
        public Host Host { get; set; }
        public Cost Cost { get; set; }
        public InsurancePolicy InsurancePolicy { get; set; }
        public bool FingerprintsPrevCollected { get; set; }
        public DestinationCountries DestinationCountries { get; set; }
        public BorderOfFirstEntry BorderOfFirstEntry { get; set; }
    }

    public class BiometricData
    {
        public string FacialImage { get; set; }
        public Fingerprints Fingerprints { get; set; }
    }
    public class CountryOfBirth
    {
        public string Code_ICAO { get; set; }
    }
    public class NationalityForApplication
    {
        public string Code_ICAO { get; set; }
    }
    public class NationalityAtBirth
    {
        public string Code_ICAO { get; set; }
    }
    public class TravelDocument
    {

        public string Number { get; set; }
        public Type Type { get; set; }
        public string IssuingAuthority { get; set; }
        public string DateOfIssue { get; set; }
        public string ValidUntil { get; set; }
    }

    public class NationalityFather
    {
        public string Code_ICAO { get; set; }
    }
    public class NationalityMother
    {
        public string Code_ICAO { get; set; }
    }
    public class AddressFather
    {
        public LegalGuardianAddress LegalGuardianAddress { get; set; }
    }
    public class AddressMother
    {
        public LegalGuardianAddress LegalGuardianAddress { get; set; }
    }
    public class LegalGuardianAddress
    {
        public Country Country { get; set; }
        public string StateProvince { get; set; }
        public string Place { get; set; }
        public int PostalCode { get; set; }
        public string Address { get; set; }
    }
    public class Type
    {
        public string Code { get; set; }
    }

    public class Country
    {

        [StringLength(3)]
        public string Code_ICAO { get; set; }
    }
    public class Address
    {
        public Country Country { get; set; }
        public string StateProvince { get; set; }
        public string Place { get; set; }
        public string PostalCode { get; set; }


        [XmlElement(ElementName = "Address")]
        public string Addresss { get; set; }
    }




    public class VisaType
    {
        public string Code { get; set; }
    }
    public class Occupation
    {
        public string Code { get; set; }
    }

    public class PurposesOfJourney
    {
        public PurposeOfJourney PurposeOfJourney { get; set; }
    }
    public class PurposeOfJourney
    {
        public string Code { get; set; }
    }
    public class Host
    {
        public string PersonOrCompany { get; set; }
        public string SurnameName { get; set; }
        public Country Country { get; set; }
        public string Place { get; set; }
        public string Street { get; set; }
        public string PhoneNumber { get; set; }
    }
    public class Cost
    {
        public CostCoverage CostCoverage { get; set; }
        public MeansOfSupport MeansOfSupport { get; set; }
    }
    public class CostCoverage
    {
        public string Code { get; set; }
    }
    public class MeansOfSupport
    {
        public string Code { get; set; }
    }
    public class InsurancePolicy
    {
        public string Surname { get; set; }
        public string ValidFrom { get; set; }
        public string ValidUntil { get; set; }
    }
    public class DestinationCountries
    {
        public string CodeICAO { get; set; }
    }
    public class BorderOfFirstEntry
    {
        public string CodeICAO { get; set; }
    }



    public class Fingerprints
    {
        public int EnrolmentStatus { get; set; }

        public Data Data { get; set; }

       //[CustomListValidator(ErrorMessage = "Logs can not be more than 10")]
       // public List<Log> Log { get; set; }

       // public EnrolmentInfo EnrolmentInfo { get; set; }

        public bool FingerprintsNotApplicable { get; set; }

        public bool FingerprintsNotRequired { get; set; }
    }

    public class Data
    {

        [StringLength(2147483647)]
        public string NIST { get; set; }
    }

    public class Log
    {

        public int FingerNumber { get; set; }
        public int NumberOfTries { get; set; }
        public int QualityIndex { get; set; }
    }

    public class EnrolmentInfo
    {
        public DateTime Date { get; set; }

        [StringLength(100)]
        public string Operator { get; set; }

        [StringLength(100)]
        public string QualityAlgorithm { get; set; }

        [Range(0,999)]
        public int Age { get; set; }

        [StringLength(100)]
        public string Location { get; set; }

        //  [Range(0, 10)]
        public double SoftwareVersion { get; set; }

        [StringLength(100)]
        public string DeviceUsed { get; set; }

        [StringLength(100)]
        public string DriverVersion { get; set; }
    }
}

