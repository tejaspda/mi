﻿using Microsoft.Extensions.Hosting;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics.Metrics;
using System.Net;
using System.Xml.Serialization;
using VFS.Caching;
using VFS.Communicator.Biometrics;
using VFS.Communicator.Biometrics.POCO;
using VFS.MI.Poland.Contract.V1.SQS;

using System.Collections;
using Microsoft.AspNetCore.Mvc.Formatters;
using VFS.MI.Poland.XMLGenerator.POCO;
using Type = VFS.MI.Poland.XMLGenerator.POCO.Type;
using Host = VFS.MI.Poland.XMLGenerator.POCO.Host;
using System.Xml.Schema;
using System.Xml;
using XML = VFS.MI.Poland.XMLGenerator.POCO;
using VFS.MI.Poland.Options;
using Microsoft.Extensions.Options;

namespace VFS.MI.Poland.XMLGenerator
{
    public class XmlGenerator : IXmlGenerator
    {

        private IBiometricCommunicator _iBiometricCommunicator;
        private IUtilitiesCache _utilitiesCache;
        private ApplicationOptions _applicationOptions;

        public XmlGenerator(IBiometricCommunicator iBiometricCommunicator, IUtilitiesCache utilitiesCache, IOptions<ApplicationOptions> applicationOptions)
        {
            _iBiometricCommunicator = iBiometricCommunicator;
            _utilitiesCache = utilitiesCache;
            _applicationOptions = applicationOptions.Value;
        }

        public XMLResponse GetPolandXML(BoltSqsData? boltSqsData)
        {

            string biourl = _utilitiesCache.GetBiometricUrl(_applicationOptions.ConnectionString, "PL", boltSqsData.CountryCode);

            BiometricResponse biometricResponse = _iBiometricCommunicator.GetBiometricAndFacialAsync("PL", boltSqsData.FormularNumber, biourl, biourl).Result;

            ApplicationForm applicationForm = GetXML(boltSqsData, biometricResponse);

            var result = Validate(applicationForm);


            XMLResponse xmlResponse=new XMLResponse();
            xmlResponse.XML = ClassToXml(applicationForm);

            if (result.Count > 0) {
                List<string> errorList = new List<string>();
                foreach (var item in result)
                {
                    errorList.Add(item.ToString());
                }
                xmlResponse.isError = true;
                xmlResponse.errorList = errorList;
            }

            return xmlResponse;

        }

        private static string ClassToXml(ApplicationForm emp)
        {
            XmlSerializer xmlSerializer = new XmlSerializer
        (typeof(ApplicationForm));
            using (StringWriter textWriter = new StringWriter())
            {
                xmlSerializer.Serialize(textWriter, emp);
                return textWriter.ToString();
            }
        }

        private ApplicationForm GetXML(BoltSqsData? boltSqsData, BiometricResponse biometricResponse)
        {
            ApplicationForm applicationForm = new ApplicationForm();

            #region Applicant
            XML.CountryOfBirth cb = new XML.CountryOfBirth();
            cb.Code_ICAO = boltSqsData.Applicant.CountryOfBirth.Code_ICAO;

            XML.NationalityForApplication nationalityForApplication = new XML.NationalityForApplication();
            nationalityForApplication.Code_ICAO = boltSqsData.Applicant.NationalityForApplication.Code_ICAO;

            XML.NationalityAtBirth nationalityAtBirth = new XML.NationalityAtBirth();
            nationalityAtBirth.Code_ICAO = boltSqsData.Applicant.NationalityAtBirth.Code_ICAO;

            //Applicant-Travel Document
            Type type = new XML.Type();
            type.Code = boltSqsData.Applicant.TravelDocument.Type.Code;

            XML.TravelDocument travelDocument = new XML.TravelDocument();

            travelDocument.Number = boltSqsData.Applicant.TravelDocument.Number;
            travelDocument.Type = type;
            travelDocument.IssuingAuthority = boltSqsData.Applicant.TravelDocument.IssuingAuthority;
            travelDocument.DateOfIssue = boltSqsData.Applicant.TravelDocument.DateOfIssue;
            travelDocument.ValidUntil = boltSqsData.Applicant.TravelDocument.DateOfIssue;

            XML.Country country = new XML.Country();
            country.Code_ICAO = boltSqsData.Applicant.Address.Country.Code_ICAO;
            XML.Address address = new XML.Address();
            address.Country = country;
            address.StateProvince = boltSqsData.Applicant.Address.StateProvince;
            address.Place = boltSqsData.Applicant.Address.Place;
            address.PostalCode = boltSqsData.Applicant.Address.PostalCode;


            XML.Applicant applicant = new XML.Applicant()
            {

                Surname = boltSqsData.Applicant.Surname,
                SurnameAtBirth = boltSqsData.Applicant.SurnameAtBirth,
                Name = boltSqsData.Applicant.Name,
                DateOfBirth = boltSqsData.Applicant.DateOfBirth,
                PlaceOfBirth = boltSqsData.Applicant.PlaceOfBirth,
                NationalIDNumber = boltSqsData.Applicant.NationalIDNumber,
                CountryOfBirth = cb,
                NationalityForApplication = nationalityForApplication,
                NationalityAtBirth = nationalityAtBirth,
                Sex = boltSqsData.Applicant.Sex,
                MaritalStatus = boltSqsData.Applicant.MaritalStatus,
                TravelDocument = travelDocument,
                Address = address,
                PhoneAreaCode = boltSqsData.Applicant.PhoneAreaCode,
                PhoneNumber = boltSqsData.Applicant.PhoneNumber
            };


            #endregion

            #region Application data
            XML.Occupation occupation = new XML.Occupation()
            {
                Code = boltSqsData.ApplicationData.Occupation.Code
            };
            XML.PurposeOfJourney purposeOfJourney = new XML.PurposeOfJourney()
            {
                Code = boltSqsData.ApplicationData.PurposesOfJourney.PurposeOfJourney.Code
            };
            XML.PurposesOfJourney purposesOfJourney = new XML.PurposesOfJourney()
            {
                PurposeOfJourney = purposeOfJourney
            };
            XML.Country country1 = new XML.Country()
            {
                Code_ICAO = boltSqsData.ApplicationData.Host.Country.Code_ICAO
            };
            Host host = new Host()
            {
                PersonOrCompany = boltSqsData.ApplicationData.Host.PersonOrCompany,
                Country = country1,
                SurnameName = boltSqsData.ApplicationData.Host.SurnameName,
                Place = boltSqsData.ApplicationData.Host.Place,
                Street = boltSqsData.ApplicationData.Host.Street,
                PhoneNumber = boltSqsData.ApplicationData.Host.PhoneNumber
            };

            XML.CostCoverage costCoverage = new XML.CostCoverage()
            {
                Code = boltSqsData.ApplicationData.Cost.CostCoverage.Code
            };

            XML.MeansOfSupport meansOfSupport = new XML.MeansOfSupport()
            {
                Code = boltSqsData.ApplicationData.Cost.MeansOfSupport.Code
            };

            XML.Cost cost = new XML.Cost()
            {
                CostCoverage = costCoverage,
                MeansOfSupport = meansOfSupport
            };

            XML.InsurancePolicy insurancePolicy = new XML.InsurancePolicy()
            {
                Surname = boltSqsData.ApplicationData.InsurancePolicy.Surname,
                ValidFrom = boltSqsData.ApplicationData.InsurancePolicy.ValidFrom,
                ValidUntil = boltSqsData.ApplicationData.InsurancePolicy.ValidUntil
            };

            XML.DestinationCountries destinationCountries = new XML.DestinationCountries() 
            { 
                CodeICAO = boltSqsData.ApplicationData.DestinationCountries.Code_ICAO
            };
            XML.BorderOfFirstEntry borderOfFirstEntry = new XML.BorderOfFirstEntry() { 
                CodeICAO = boltSqsData.ApplicationData.BorderOfFirstEntry.Code_ICAO
            };
            XML.ApplicationData applicationData = new XML.ApplicationData()
            {
                NumberOfEntries = boltSqsData.ApplicationData.NumberOfEntries,
                DurationOfStay = boltSqsData.ApplicationData.DurationOfStay,
                DateOfArrival = boltSqsData.ApplicationData.DateOfArrival,
                DateOfDeparture = boltSqsData.ApplicationData.DateOfDeparture,
                Occupation = occupation,
                OtherVisas = boltSqsData.ApplicationData.OtherVisas,
                PurposesOfJourney = purposesOfJourney,
                Host = host,
                Cost = cost,
                InsurancePolicy = insurancePolicy,
                FingerprintsPrevCollected = false,//TBD
                DestinationCountries = destinationCountries,
                BorderOfFirstEntry = borderOfFirstEntry,

            };
            #endregion

            #region Biomatric Data

            Data data = new Data() { NIST = biometricResponse.data };

            List<Log> logs = new List<Log>();
            for (int i = 0; i < 10; i++)
            {
                Log log = new Log() { FingerNumber = 1, NumberOfTries = 1, QualityIndex = 90 };
                logs.Add(log);
            }

            EnrolmentInfo enrolmentInfo = new EnrolmentInfo()
            {
                Date = new DateTime(2015, 11, 30),
                Operator = "YULIA KASILEVA",
                QualityAlgorithm = "NIST",
                Age = 31,
                Location = "KALININGRAD",
                SoftwareVersion = 2.0,
                DeviceUsed = "Cross Match Technologies - Patrol ID",
                DriverVersion = "V117.41"
            };

            Fingerprints fingerprints = new Fingerprints()
            {
                EnrolmentStatus = 0,
                Data = data,
                // Log = logs,
                // EnrolmentInfo = enrolmentInfo,
                FingerprintsNotApplicable = false,
                FingerprintsNotRequired = false,

            };

            BiometricData biometricData = new BiometricData()
            {
                FacialImage = "/9j/4AAQSkZJRgABAQEAYABgAAD/2wBDAAgGBgcGBQgHBwcJCQgKDBQNDAsLDBkSEw8UHRofHh0aHBwgJC4nICIsIxwcKDcpLDAxNDQ0Hyc5PTgyPC4zNDL/2wBDAQkJCQwLDBgNDRgyIRwhMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjL/wAARCAKAAeADASIAAhEBAxEB/8QAGwAAAgMBAQEAAAAAAAAAAAAAAQIAAwQFBgf/xAA9EAABAwMDAwQBAgUCBQIHAQABAAIRAyExBBJBBVFhBhMicYEUMgcjQpGhFbEkM1JiwdHhFjRDRFNyc/D/xAAZAQADAQEBAAAAAAAAAAAAAAAAAQIDBAX/xAAlEQEBAAIDAQEAAgIDAQEAAAAAAQIRAyExEkETUQQiFDJhcUL/2gAMAwEAAhEDEQA/APtUCbIX4Si2CpPhUDIXyjyjkIBSpO3GFJvChmb4QNCCCJQnhRKO4QBNroSJmEZi0IT4QBLvCM+EtsI4GUBCgQZlCeJRJJQAMlEKYyoRIQEKl5/cELhQjmLoAmMI8JCYOE0oCIAmUMG2FMpA0iEJUiAg50oMwHKMiFXMcqAlAMHeLKF2EAZGFGuQDB8oySEoI+kCfKCNIlCL5QLgVOLIAkn7RBkYSeZRBJ5TBHF2+AFYDAulmEP3FA8OIARJtCQI5uEAwsgSQ5LKJdISAzyg0ooIMcnCkcqAokiYQSB0hTcJiFI7KcJhCIU+lNqgQBmUuyCmtCkoAIiyBcJCkyUAclQgA2S37qZCAORdADhQSmQNhPCEWnlN3QFwgII7qGCjAUGEATlAuvGESgQgCCoSSLG6XCIQE4k5UH3KExYox8pCABNlA74yjFylkC0IA7lBBvKBbIQxCAIsUTBUIEoTCAkXwjgJS4i4RmUAdwlCeQoZm6EwUAZlsqSUJEWQkzCQ0NzyphVyZys2s6totBH6nUspzw43Stk9VMbWwuECbIbwTleX1nrnpNIP9pzqr22AAiVwdR/ELURFHSsBOCTKyvLPxpOHKvo5KUkd18rreturVTAe1gP/AEhYa3qTqb//ALqpPgqbzX8i5wPsLYvcJgRcSvi7fUPVmfJutq/3W6h6361TB3vbU/8A2anOW/sF4H1mRwoDdfO9L/EeoJGp0bSe7DC7uk9ddH1DWh9Z1J54c0/7q5yxF4so9OUQ60QslDX6XUt3Uq7HNzIK0Nc12HCFX1Kz+b+nmApMnwlJhV+40GS4D7T3BpbI7Ibu65+o6votKXGtqqTYzLlxtV676PpyWiqXu42tJCn7xipha9STZDd2XznWfxEqvluk0229nk8LlVfV3WdQDt1Htj/tEKLy/wBLnDa+tlwAMH7SioIEuhfF6vWur1id3UK4HYPIVTtZ1Jzb9QryP+8o/lX/AAV9u9xpEBw/umBAbMiF8N/W68AOOurk/wD9CtlLr/WaLA1mtqlvAJlH8tK8D7QHTyiXCV8o0vrrqmmc01WsrNGQRH+V6bpnr7p2rcG6prtO8mL3B/Kqck/UZcOUeyB4UHlZqGqo6hu+lVa4cEFXyQFcsvjKyz0xthERa6QXF0UyWbpSkdlIgXUtFkwkI4wpII8oCSgDPMISQbqWHKhIKAn5UxgoGFAUAxugoM4RKAAJRlC4NkQLIA/RQ4RwhKAhBIU2wMoi1kUAsiUQI5QIACguEAZhSyWQLKG4EIBphSZCB8oW4QDEwEpxZS8o+EgW/KhTFKYQYoeVATwldKCNulCUm4/ao1GsoaWmaleo2mwZLjCVulSVoJ7rD1Dqmk6XpzW1VUMaP7leT636/wBOwCl0se8++57gQAvCazW6zqdY1tZXc8k4mwWeXJ/TbDit9et6x/ECvqC6l0yn7bce48XP12XjX6rU6mu6rqqr6tQ5c4yiAZAAsE/s3nusbl/bqx45IqhoFspw7aBCZ1ADmycUxsAtZTaqRQ7dvkTChkXIV+2bKNp7pCW1aZH1DEAJPdcATNlpq0JEBUVNM5oJVSxFlVP1AiyQV2kQYCFTTPm0wVmFJ4FwQtJpF26TNdUpx7dZ7T4K7Gk9SdR07QW6hxH2vMi0StNJ1vypyxOPVVvWXV303U2VA2R+7lcmp1LqNYE1NZVJOfkVnFxMcJOVEP5kK+iazt1So4z3KZlBkxGOU/vCY2yFGuMkwjapjFvtsiyBZiMJdxJPZM1yXauoIYBlTaZ8KbjJgKwbyywgpbBNoxFkNpBPZO02vZOG/FL6P1QGEunuke1rrEflaQ0kpH04IMJ/RaX6HqOp6fUa+lWcNpmJsvoHQvWOm1wbQ1bhSrYBNgV82LfnP+EC0yDJDhcEK5lq7jPPCZTT7ox4cAWmQmyV8z9N+s6mjqN0fUSXUiYbUP8AT9r6PSrMrU2vY8Oa4SCDldOOcrizwuNWg3hNCRoM5TR5WjMbghG/BSxHKbiyCCbXCV4OWpr/AJQmDdAATyiIATZ4QOEBLxlQeVBgKG1+EBDYhRuSUZUjwgJKBuiR2R4QCg3TAg5SugKR5QBP+FItKgQkY4QERCEqTZICXeFAfCUm3hAmIugzhDdZBQnhBG3AhKdqEpbziEb0rQ/lK5wAkkCFyOr+odH0imTWqB1Tim03K+fdY9V9T6wTRpTp6BtDDcjyVnlySeNcOK5PX9c9a6PpRdQoRX1Iy0YH2V881/U9d1mu6rqaroJkMBsPwqW6ch8Oz3VgpEOgFYZZ7dWHFMWelRibD7VvtjbHKYAuECyDaT92ZWVyayFbZxAGE9nAq6nQeTjK0t0UNveVFzkVI5zQXZwE3tuLp4XU/wBPG0EBP+iBF7KLzYn8OYaTtsgJ2U8WgrpfpgGQqzpSTiP/ACp/llP4ZaWnLhJuVY/RSJha6VDa7wtzaALYUXm1VfE084dKb2sslfSiV6XU6baxxaFwarXB7must+PktTljGA6IGwlXUtLtYBBCdry03Wyg73MwtLnWcxjG+wWZzXOcAJXSr6cF2Mq7SaMF253CX3JNn87ZtN055Ac4WW9nT2AXCvfVp0W2IssFbqTg74mAsvrPK9K1IavpmMp2gRwsZLRYBJU1u4kl0rG/UySRhbYY5a7RllPxsNUNHCup6hjxb8rkGoX8pmF/9JIV/CZk7HxPybwrG3GFzKTniJlbaLzjgrOzS4ubG5MNtzlCmPnJyrHho8LPa2d1K8pAINx+VosRcpXgOaeFcqdMVem19hnuu/6W9VVOkV26PWuLtI8wHH+g/wDouKWkBU1KPuNIIWuOTLLCZPuVHUU9RSZUovD2OEgg5Vv2vj/pr1Nqeg6oUtQ59TRkwW8t8hfVdB1LSdS04r6Wu2ow9jhdOOf9uHPjuLXblFpEoE9wpMLT1mbcPyiXSMJQYT2KAXnKMKRBUm8Jkl4RBMISMIAXQELjwpuJsSjAJUiEAQbKESEE9otlAL/uhNzIRmR2RwEAqk/3UNyhF5SCFEYQJR22QaJSAcqGyBMpgZtlBQkLy/qP1dQ6TOnoxV1MWbOPtTllMVY43K6ju67X0dBQdXr1Aym3JK8H1b11qtY91DpzBTpzHuEfI/8AovOa3Wa/q2o97VVnEE/tmw/CejQ2gWhcvJyuzj4P7A0jVc6rXcalVxklxmSrGgbZACc07faUw348rmuVrpmMhXibmFU5sROVaGlxzCdtA7gSEvpWlQoEv+IzwtA0wxgq9rAMYR5IWdyOQraQYLGTyr2OEXCQDaMoCS4ws72tpbUbMJyGwsgkFWtLisriFoiCm2tcASqdjii1hLsqDXe20rTTaGtELOxsAkq1tUAAJXYStDqZDguJqNKyo8mBK69VxcMwsRGTC148rDsc79APrsizSupm8fhb8ZCzVq4pgyRPC3meV6RqKqjmsEnKw1NcQSJgKvUakEuLnLlvqF5tddOHH/bLLP8Apqra1xNiszqj33JulbTLpkQtFOiCO61moy7rLD891ZT073ldCno/c2gD/C6VDQCZ/wB1GXLMVTj249PSGYLbrQ3QveYDSAu2zS7IO1aP05F4iVz5f5DWccjjt0Ba0CFazSuHF11HUcIENaPKz/m2fywGi5pgi6qcCbEQumYNylLGESQETkGnIeCHSMBKasCy31qTT+0LI+ltxlbY5SpsVe7vbhEiBIMpgCGFtroBhECZV7Spqta5kkZS6evq+n1BV0eoqU3AyADZbTTa4RCUabcc4VTPSbjt6bpH8Qqh1Ao9WY1jItUYDb7C9zo9dptdRFXTVmVGHsV8bq6MPBkSVnoV9X0yoXaetUpnna4iftb48jnz4Y+7kCAQmNivnHQv4gvDm0uqMlpMe63jyQvoGm1VHV0m1qFVtSm7DmmVtjltzZcdxaAZCCgUhWhAfkiMpSPkiEEjsYRbMKTaFAmBUGcobkdoOUgWeCjuEwo6DdL+UwcjlAXF0pmIlG6AgkcJg74ocXScIB+JSEIXjOVzetdRZ0vp1Wu+oGkNO2eTwFNuorGbunA9Yeqf9OpHRaN3/FPEFw/oC8BQpVKtU1KpL3m5JuVW6tW1uvqarUHc95ldOk2GA8rj5c3ocXHpKdJsX4VvxsMItaACSVTUJfMYXLbt06kGrUvDSAqZJcHFKAXO+lfSZI8J+F6LGbjay0NzAJKgABsm3AXAWVq50IkOxZRwvKeZCUmDBUmAG7CtY0CyoIIMzZAVgIJKVlNuDASCrW0hMBc86q0zCP6pwI+azvHlSdQUD4VjNLeSVyxriDt9z/Kh6lUA/fhZ/wAOYdf9OSz447Kp1A7v2rEzq9RoFwfMLT/rDXj5MCP484Iz1mPa4yD4WcOmy21NXTqgrI9zbkQrxlUQ2yuL1En3DtXXcbeFj1FIVBYLp4uqjJ540zUedxsnZpw2doXQ/S/KNuFczR7wuv8AkmmPxtz6WnJMSSupp+n7yJatek0AYZiSV2dPQbTZcLk5Of8Appjh059DQBl1rZQa2bf3Wv4ASqK1VreQuS5ZZNJNEDQDcIeSkOqERYLO+uZzKcwo6XONzBsqXmRKX3Nxylc9rbTdaY40XQkmJSl0MMqh2pgloVb63xg8rWYJ2uLwbql5AlVuqtDYlVu1DHWHC1mNRsfOE4gmyzGu0H5H6R98RIVfNTtqALbohxAsqW6guYAmFQSGgJap7OS7cAEA0PdDwCoJJhC7D3Ce6TNquntIJpyF0vSXqI9B1xoaku/S1TDr/tPdVN+crFrdEaosPoha8fJ3qss+OWPt1KrTr0m1aTw9jxII5VmSvlHo/wBV1elV29N15P6cmGvJ/Yf/AEX1SlUbUG5hDgbghdmOW3BnjcaY5UAKPEo3VoQIHMhNCkXQQAonCU5hHATBXRgSpEiyaCFMJAojlAyDM2Uj5WTcwUwkg4wlIPCIsYChykFReGAudAaMyvlXrDrjuq9TOloP/wCGomLYce69v6x6p/pnRnkH51PgCvk9NkgPOSsOTJ18OG+2miwH/ZdLS0i920ZWGk0NIhbqB21Nw4wVxZ3btxM87XFpyLFUiJdexVtZ/u1S7k5VQaN5GFChawQFbTa0yMJdsCOVYW7LJWnDyJQdIQc9rRdZn6g7lMlp7aWPAMEoOqjdlYy8ugglWXMKvktnqVHXhVOqgNE5CWoH7hP4SCk6pI7pyQbqupqCACJzhK+u8m0wtTNC51iLd1ezQNOQSe6r6xharme7UcYbMhQ1XFhBmV126FrQYGVP0bYuEv5MR81xW1nzAJsrxXqG5JAC3u0DcgJf0bcOEJ/eNGqop6t4bYqz9XLo/wB1UdIWuIx2TDTFtylrGnutVN3uAzwptnCraCxqtY4DlR54rf8AYtbGLKxjAAhIKStXbRpklwCnu9DqduhTqNY0GQFXW6oxlt0FcCp1CpXO1gLW8lKGl3Cc4P3Iv5G2t1ZzXEjCzu6lVqPEN+PlAaUvsGk+VoZoYAxK01hiW8qr92s5srQ0VXNAkDurGaQgBWigeFFyn4clZDTcD+8wnDSWw4rT+mJFij7MKfuHqsLqQEkZVT6ZIuuj+ncVW6gQO5VTOFY5jqLi2OVQ6k4WXUcwh8QVS6mQ8rWZoscjY4STKALg7mF1PbDgQR+FW+gHRAhaTOVPyyU6hDvC1MqiZ/yq3UfiYH9kgBZY4R1SbWvIMi6skPMSsDahBytQ27AQb5U3HQ20bYCLTzEnyqhVsnD9w7FTpTn9R0ge4uGTde09Aeoob/pmreS4f8px7dl5WtJELD79Tp+oZq6RLXMdIIW/HlWHLhLH3qICi53ROps6v0ihqmOBLmjcAZg9l0QuyXccFnekIgSLqAkogQFNpGFSUIUbdTaRkoiUBD5KWSmMkoEmEABi9kPBQNwiJxCRoBHKhQO6EjnltN05ARRHzX+Iuv8A1Guo6Km4wwS8eV5mnDmhpFwn61q/1HqDVPIJAeYKrpEOItErkzr0OOajVTsIjC0UqloKoZaUwMOsuWt4uuXSEA2DfKVpMp4gyfwp8UsDxMzjhB75cXd0kDZPKUmB4S0NkcbyTZGnQLrzKYU/du0Lo6PRn25vlGWcxg1tnoaUvcTH5Wn9KW8CV0BSbSoxzlUVKm4ARC57yWtJiyfpvc/dACZumAuVdtKupU3vG0CfKJcr4LqeqPbDcCyZrZNhZb6OiLrHK1M6e36WuPBnl6zy5sY5IpF0CDKc6UvNhaF22aINFhCtGlA4XRP8WfrK/wCR/Tzw0jgYhR2iMS5sL0o0zDxdK7TsIiFX/GxL+evK1NJA79lndQIGF62poKZaYaJ8LC/QRIiVF/x7PFznl9eZqMLeFQ2Su/V0FyDZUf6ffFvCz1lPY0+pXFc94uAs9XSv1Dw8yu+7psYBRZotictn4Oq5NLRANj/ZaqekY20WWx9PbZD23ubIGFllllTkkVNYxlosm+LneArmaSrUgbSrh02oPCXxlT+pGZsTKMfOVq/09zbgm/hRukfyCFPxkPqM+cIbm85Wn9G/cYBVL9M+f2pfGR/UKSLIFozCG1xEcoOY5rZmyXzYcpXUg4ou0IfBthQS25Mq5lSMpbyg1Kw1dBEkZWV9DYIK7zXteIVVTSscTayvHlv6Xy4Dm7RA5WepTF4XYqaSCSAsVegW5C6MOSVncXOLCBJuma4usr6rQIsqA6HEAWW0u2dh23MK5oi5KVpAbcJjDj4CmnDPvnkLDq2B9Et4W87SyyyVCPbLclVhdUZePYfwy1jvY1WicRDHbmjm+V9DDieF8f8AQ2tGg9StYSQKw9v8yvrwPK7uOvN5ZqnnwpJhKEQclWyNNroXIhAGcgwiCQgDIiAkN0+QFMoBAD+FDY5TEoTPCDLBM3ssnUnGl07UP7U3X7WWzH0uB6x1o0Xp7UOa4B7xsH5Sy8VjO3x+mTVqVajuXFbaDQ8gdlmoNLWYseFppiHSCuPOvQxjSSGmAiOSkjcJVlNpwsK1i1rQ5nYptpyUrYmDYqOdaxsoUD3ZCDJdaFHtkW5W3Q6bcW90sr8wRbpNMBYhdVrQxg7JRTFFsyFlq6iTtC5bblWkmj1Ku9xAwqw0vKfT6WpVqbuF1KHT2tEnPK1w4LkjLlmLHQ0jqkEj8Lp0dLECIWqlQDYgQtAZEld3HwzFyZ8ttZxQgCFa2nhXN+kS0uC6JixuSstAvwo7wE/MQp4TKFFrpSRuTbdphQNhIykWuk2tm4VhzdTaDMJbVGZ9Bjx+1VDSNjC3BloJshtACnSvpi/StOQkdoWuPhb9oQAglTqfpzKxzv8ATWZIBVg0rGxAC2IFt7iEvjGK+rVBpgGyjmA5VpglCwyEdDshaNtkhYMAK4AA+EC34k4S1D2oIAEQlFEG5Fla5siUwFgp6PbI/TscTAuqKmiaQc3W53xJso50tBhLLCVUyriVdI5gwSsjgWheidTLhcWWOvomVLix7Lnz4f6a45uUypBWplUPthU1NOac2Nlm9wscsMsWku297NwsslahJwtFHUNfAJTVGAnNlM3Dee1VItdELOaYHy5XZ1lJpYuK9zqVSD+1dnHluMssRa3cQJVzW7XwcKNaHRCtczsqtKRWSIthZKjZBMwtbuxWSoflBVYprIKx0uroVWmCHgz+V920lZmo0dKrTcHNc0EEcr4HrpLfAK+x+jdYNZ6Z0h/6GBhPldnHXDzR6AGUQg2QiJ7rZzmBBUJCWCJUTJII5QmCmILrKsTJCRmyVCPKkQVCgAbhfMv4g9SOo1tLp7HfGmZeB34X0HqOp/RaGvqHYpsLl8YrVnazWVtTUJLnuJusuTL8b8OO7tXSb8tswIWik3wkY35SVbDgQuTJ2w2+XQr6bvlIWYgud8bLRTbsbJElZ1cWOgmUliYVpAcycEpA2Gwf3cKFHpgOft7LtaVgps/8rlaSne/JyurXc2jQAm6w5bu6aYs+q1ZNQMbda9FoTVIc/wC1h0OnOp1G8/t8r1WnoNbTEcLbi4ox5eTQafTimYiy2tpwmYwWsrQ2Grvww04cstkA22KI84TCTZQWK01EbTHCNgJ4KE3RBkIEANkx/lJtIJT7uQlkTlKnKUmT8lAZKciyQ2KnWlQ0Ai4VZEGybN5hQhJRLgeE0WlQG0HCkCUjQZS7TuM4RJvARdBGboMhbayTmCrDbCT7ylTgGJlAiRdHaCZCMQkfZYEWKUOkwU8dggRCVNXIlSRxlPtBFwleEjIZJuoNs3wiGkkylgByNGV5BNgl2tzCYgA2QKlTLqKO8FcPV0iwmy9IQsGvoB7fiLrLPDfcXjk4FKo6m666tCoHDzC5Gqpljlbo6xLgJwufPHc21latQ2JXD17IkheirM9xkjK4uvo/Augp8N1Rl4w6WrJAcukRBXFpu2akA44XYY47J5W+c12jFU5s3WHUZldM3aJWDWASFWFTlGCuyabvpe6/hj1Eu02o0NT+g7m+ZXiHEgdwtXpbqX+j+pKNapPtO+Jg97SurCuXlnT7eDdMLqum5rwHNMgiQrJkLonbisE4UBHZATtRkhMhcbpNvKYkGyBM2QEiyHKP0Vx/UXXKXROnurOMvIhjRklK2SKxxtuo8n619R+5Vd0rTkhrTFV3fwvHU6Q/cCi6o7U6ipqa53VahLnEq1rbCMLjzy27+PD5hS2Gi6O6yNSxhCLC0rNrFlNsfIlaWgOZ+VTSYecK6NswFnkuGb+6CFC3dEhRpcW9vKtYAbg/hRdqbNIAy3HdHUuFZ+wfSpbULBEq3QA19UP+kFZTG3LZ26jt9P0YZTFrcrs0mQ0ABU0KUBvYra0AQvS4sNR5/JnuhBblWA4CBABg4UIhohbsReLWSubMGUSZCLsYRoEj4+UcjKnCBiLICGEpbCY3FkBm6SoAMCOEREowRhSQpplPKrmAnMzHKAbe6lcKeCmkzYZRIhCboMeZKQtuiLE3U3AJAgM2hTlNAvCSCCDKRpabIEFs9kYhE4SUqJPdGSWyjBP0lII+klAM3wgbmAju4U4xdL0FuJnASkDKtdBEFV7QinKhACpe2HTwryFWfKVOKiQQoWNqABMYg8ID4nFlOlOJ1HStBMC647R7NSSYC9ZrqYfQLouvK6thLicFYZTVa43p1aNTfTCxa0bdxsR2T9NcQ26fWMDmnhYzrJXseWrsLazTi66+mdupiLlc7ViWyMgrd05wNAA3cF1Z94s8fV7m3mFl19Me0HjhbiRyqazWvpOas8bqqyjhzI+lRqGF7Q4D5DCuqtIJhI02AOF2Y/258pvp9I9CeoDrtEdDqqs6ilZs5IXtQQF8HpVq3TtSzW6V5bUaZsvrfpr1DR6904VANtZnxqN7Fb4Zfjj5MNPQNIhGAbgqttgmC1YiBCBnui5wwVm12toaDSVNRXeGU2CSSi3RybUdU6pp+k6J+p1Dw0DA5J7BfJusdZ1HXeoGvW+NNtqbOwT9c6zqOv641Xkt0zDFOn2/91mZQkCBeFy8mbs4uPU2qaDkhX72mwKIYWi4VboMjbCw3t0wJDnwBI7q1oJnsElNhLICuY0gbSFNpxawyAo7dMIgQJ5SPcQ7KzUt9y4bEgK1uJiFmplseVpH7bXSohKtUhpXW9P09x3O4XC1LywiRK9V0BgGmmMwrwiOS9PQUWyJ4C1DbFzdZ6QgKyw+134eODP1YBBvdHbJUB+N1DBwrQUggqSSi+LISAEbOJ+6EHAIm4slsRdIIAgTJTbJ8FAsISqoGVHYsgoJ5UbUBBBkKCSZTk2hKIsQkqA4Fp7qC5RPhKTDkbMP6sIuJBh1wo7EhQmRdI+gNhZIDeCmJtBQ5E4SAH42QJUcJKACRjHZIU7YAgJDYnlJSO7hLJnsgHDEJwJSBCe+VJTET2hLEJbMIMZSvCYixjKR0JeqVuaBeUgPyATnCgFgUU5UfenBwvNa6jtqv+NuF6QGZBXJ6gwBxWPJ/a8Oq5GlcWPgWWqs4kfJUYMhF1Qlt8LC93bZydZSILoEhP050NIjwn1R3TxKGhZAP3K6P/yz126Dm2BhVEzYiFcJLYKG1Y7W4Gvo+1WmZB4WQCV1+p0SaQeGztOfC5M7eF2ceW45852tY6xaRIK09F6vU6B1VlZpPsOMVGjkLEHWS1RvZtIWs9Z5Tb7vpNVS1mnZWpEOpvEggytAtFl8s9C+oH6DVDQal38ioYYSf2lfU55XRhdxxZ4/NSoQxpe4iGiSV8m9Xdff1nqP6Wg4jS0jFj+4r3nq/qjemdFqkOh9QFjf7L5HRJf8iLkysuXJtwYftbNNS3ENGAujsbTaIF+6q0lLYwHM3R1VXa3aFw5Zby09CY6jPXqg1ImAEn7gkkE4VjRDQR3V+JMxrgbWVpcDblIXEKMdB8qKcWHCpLYM8K0uEGVS8jMokGzsLZhbKZMLn0iSV0KYOwKczxUVm+5VAK9d0imKdBove68u5s12E97r2fTqcUaZAtCrj7sZc3jpsBhMByoCWgIm67504KO4xiUSJFkhxlRpsZKohJICmeFLBTKDEDKGALozIUABMBIFkg5UMblCPl3RMAXCVUEQpZS8KDypqgtykLTPhO6OyUuPZJUQSAhAUBhEGbo6MdwAAhKfAsiQIS+EAZxYSlcJRAg3QdPCRhHBt5RcwgTlQwW+UskQFOjARxlAiTKJu5SBMpGrLYKBBF4snc4ibJQ4kRwjRwBcIQCJTxt4skBLR4SqoV0lAgBO4wqy6UtCFN8JARMJnF2AkFnYS2orHCFj1o+JdC1mzpVGraXU/tZ5zrapbtwyPlKrfeVdUBaYWeoHYXNGzHqPqxVmh3EOJwlqTKfTEh9sHhbW9FJ22kyEoM2TfuIspABWKlFakXsc3uFw61HaSOy9BUMiy5erpFl4sVvxZM85tzQ2DKLmy61kw7RdGIEcrplY1nJqsIewwWmQQvs/pnqQ6n0OhW3bnAbXXvIXxsg3XuP4aawB+s0Jdez2jv3W2Fc3Ni5/8QeqO1PVKWibZtMBx/K8/p6ZqPDRwk6pqDrer1au4vmLn6Wrp7YM8nKy5b034Y6oG1gHhczUVC6oQulU/wCXZcurBqW4XNh3XTkraSMrQHN2yFULmVHEgyArqIdrw4pyAPkOVW2OysaJwFNMwJi91S/JutApwFlqtIdYZRiVX6d4tDZC6FKRwuZpDDgCeYXXaQGrPk6Xh2oMnUN2i5yvadMI/TsmZAheSYyagteV7DQNiiBCvg7rDn6jeTuhuEQdhg3SNBmVYLr0I4r0EAuUMgwibFSdxlMBIm4Rg8IEI8SlsI1210EZUkhyWSVCbIGhOZCP7hBSi4lQOg2U7VIDj8oTDF8oxuBnKBsEqZCZMojEqQB+UbAQpUWJuFIsYymPEYSwRdBlBOCFBza6JMFGxBQcACRdDaQbogxZRzjIQAiD9qOAIKJKUAlAJtUIP0j4UbE5spqiGQ66FoKt/cq3DbKR7Lu+MITIghG0TF0ATEwkZYuQkgbrlWm4VcQUqqFcIPdVkwU7pJkKsNMySppptMykqgEG3Cd8k2UdembJWdDbg1WgPPhZqoM2W2u2HHm6x13QuOe6dE8YnXMFNSZtMpS7cZhaKQsDwtMr0ItbcAqwsHKQRFkS6RZZLI4BpKzV272FpWlw5Vbrha49IrilkPIiIQDQXXWjVNDXyOVWWS0cnuuqXpjYpIGIC3+j9c3p3qhr3E7ajS3/AAspYWtPcrPQe3TdUoVSJIm34WuFY8s6YqEguJMkrr6B0+FyKQBYbroaN20huBwUuXuK4q7LnSwLmuaJJW1zjtWJ3yeRgrmwmm+RqZAZMJC4z9oNO0Xypkkq/wBQYSXQFqAAI7LKyd0tK2MEgSFOSoYw4LLWMELUGxhUahoLSTZTj6LFFFpNQnIldpjZYFxKIioCDyu6xsUQZU8ysFmnbNYSJuvXaVu1oXmtAzdVEi8r0+naSFr/AI8/XPz1pBAChMIPHxnlCLSV3RyU+MYQach1kGknlQ2F0tgwMHwgceEAZHhCZyga0abQhIUDhKDYmEGMxi4KUC6JgGFBgqbTg7i0xKk3ulyLpmuBsUGEEuhSe4QdPCk3iLlBnmQCliXEpiOECeUjCBzdGwwpPhLJJwgFdcppluFMZQDoS0EtF1OESO6HKDLt8obYCctSnCAWYGECZCOUrTDkjJEJRMKxwyqwSErFxAZKR4IKJO0/aDlFVFckTISzKsdYeUgByMhTpQSQ6Cg5xuNqYjmUpBjNkqHO1FMEnhcmsyCV3KzbXXKrtlzgVy3rJtjenMF3ERZaaQgeFnLhv/wrmEqsvDx9XhNshqVvxubp90t8rJSl4cqXvMEK5z5JBwsryRe5WuKLWXU3A7KtjiIBT1ZJulpibAyuieM73T1oLJBwuZVI/U03dl0n0yWFc2q0OrsachaYVlyeM+nALDPdbKREieFj0zxtgjlbGQVeX/pYeOm1++kL8LM4AvnlFp2tglQXKwk1W29pEfaWCT4VhZaZRaIFz9I2R6NOVqa2L9lVTMALZS2ubHKxyrTFSAXHsFk1BAJC6DmkArm6rkf5Tw9LJnZZ4HMrvUzLACeF52l8qwM2lejoM+LQBdHNBi7XSqUjdgwu/SHwbdc3QM/ltteF0mS0XXTwY6xcnNd05Nks2U/cUBYkLo2xSYtKZVOgOQdVI+lFy0qRaHbRE2KkifKxu1bGkAuAnukdrqYJO9tkfUGm+YKm6SVz29Soh0bxfmVaNZRIBDwj6P5bQQRfKl8BZm12nBVnuYujcGquBvdQxOEgcCpNkASZKJuBCWyIeBwjZjIiCUGvGCUN0mIQ2xeLpA5IixQBJ5ulH0mAvCexBgoAZRjypICKAF1Da6hP0Eu7ykAkyiTtyJBS+4GCSVU/V0zYkBLej1Tk3lqhADpBWOt1CjTJG8CFzq/qPSUnbTVaCl9K1XbnuErxIsvPVvVGiAB90JKfqzROF6rRwbqbVR6AgIF17hcIepNJUdaqHLpUtdSqgFrwVO++1NRINlXiQVA4ESCEHTmEXs4EzMo7xt2iUoFkQNuUjZq1phcnVtgk9l2azTt7rl6unub54XNnNVpg4z43XT0nEuA4SPBa4hyspRFueU/xXla2g2EJqjYIII8oUnTlO+NslY31Sg1NtNzS0X5WOo6BYLXVI2grHUI/C2wZ5M7zuM8JadqmLIm08hNTE5W34z/TvBNMnAXJrHbXBInsV2KzdtK65RaHamm0kQe604y5PGbTiKOFqp8GFUwENurmGPpXlU4+LCQbTdWMiO6p2ixmVcwCbLKrho/srqTSTiftUmWrXpxJElZ2qkWNp91qDA0Dwla0fhWwC2ALrnyyayEeWtaSbnsuXqYcT5W2tMFc6qd2eFtxROTOwEVAcCV6bpzC/b3iy8uCTVgr1/QmtIFrwtcsds96j0ejbtbBytou02VFNpgWhWEkAyunGajjzu6hLW3JWWrq20wS4gdpKx9T6gNM0uP4XidVq+pdYqOZRJaz/ZHd8OR2us+rtNoTsY73akTDSvKa31t1PUsLKMUhOWi61aP0Xqa+oDtQXOBvH/uvTaP0fpaTRvosPiJVTGfqbbf/AB84qarquoAc6vXM93FVOqdQYW731yDi5X1xvp7SsENpsA7QmPQtIGlpYDPhV/r/AEWr/b5ENTrZG19WRwSVa3rPUaf/ANao0juV9X/+HtFA/lt8WwsWp9J6Oo2GsBI7jKP9aJ9f28JpvV2spQHPcSuxpvXNUP8A5kObFvC1aj0Vp3H4s2rlaj0ZUpNLmEx/hTcMVTLKO9o/WtB9UNfa+ZsvU6Xqen1NIOZUBnyvjup6Nq9K4Ei02IWrTa3W6ItLXmFFws8qpnv19lY6WzMgpm3OV5DofqE6gNpVv3/7r1NKpvwp3/a7OmiPlMokHKjQDcIxyFSA2mJJUEflCTKaU4A7qvBTlxbxKqLp8Kb0chalUDNlwer+pdL034ueC/sCqPU3WHdOoH2xueRDR5Xzh2l1vUKrq9Xd87yUTH6GWWnoNd64qVDFKQFxq3X9fqKu5tVwHYFXaT0vXrFpe1x8QQvS6D0jSa0e5a/CvWMRvOvGGp1LUnd/NPm6en0Pqer+Wx0cEyvqGn6RpqEBrGyPC2MoUmW9sD8I+pPw/i/r5nQ9L6xzIqnaR3VjvSGpa0HcDPbhfTjSYf6RKB0wJgiyPs/h8sd6d1OnJMyI4VlGtrdC4GHgAcr6Y7Q0jlsrDqejUawIgQlbL6rGWePN6H1EWkNrWJK9TpNZT1NIODgQV5rW+lQfk10H/dHQ0NR08BjiSJysssNdxtjbeq9bAi6JvZUUKm+i13dWyDwohkq/LC59cfEghdE9sLHqAZJ4WXLj0rCuBq2w0qinVAAbC16y5MBcoOcKzowpw7i8vXYpOtcZ5Vpu3GFho1SQBOFuaQ5mVhnuVcZawgGVifAlb9Q21isD8rbj8RmoIJVrSG2i6qmbJ6YgyStr4znq7VP3UBiVxtSRva6Y2rq6gbqVshcXWuIpyeCtOJPJ40tbAEXVoDSBZKwbbBOGyZaUWhIBxYK1jYiErWXtdWgbTErO1UiwMBCupMIKrZ8srVTnACyyq8YtYIwrQ6yLANt8pHENyue91r4yayptB8rnD5TCs19cvdANgqKTvhK7MJrFjl6ocSKn5XtPTYJDHGV4t7t1UjsV77040Mp3M2Anutf2Ms709G0wMKusZb8VY0SFNoK6XJ+uFX0J1L/kZErZpem6ag2BTEnwtwYA6wsoWkSVPit7K2m1h+IhWbYsCqg+Ch7kOS+hIsLEoaLyk9+P/dVurW7pXI5htfDQbhQgcLP+ohomCiK04S/kh/FWuY14vhZ6lEOEAWVragIhNY/ScylP5cjUdHoaiWVB8T2XF1fpBrzNF+0ebr2EbnXwjDQI7pzIWPK9P9Pfo6gc4y4cr0lFu3hWGmDyrKbeBdK+nv8ADsmJCsbMJA2O4TgFOIt1Sm0pTNk9puErrlFmgVxVFS1wrXGFkq1L4MKMmmM2w6zptDWumq0OHYhV0+jadp/aIHZbwdwTtwlMqq4q6elZT/aAArfbHBTGOSjIDYkJbLQBg4yiQOUgqRkoOqo2eqvACMzaFm9wED5Jm1o5BR9D5rQBxCU0zeUW1WkAp/cByrllT3GWpT3twsNbR78BdglpSOaBgWSpy1zqNEsAaOFeGgWwrS3EWSFpkypXtS9ubysVXdBHC6DxDVhq3mSseTxeLjalsE+VxHO21YK7urP+F56s7+cSbXUcTTJ0KJBAhdGkJELk6RwIBldai6I7LLmmlY1XWBBIKw1KYAIBXR1FnQudUBlPivRZxQ4NaLZSsG508IEm6ZrhEroZRfVE0lx9VT9xm0hdljg5nlYqzIqERZVx3VGc3FTLWyrqbARIQYzwr2ja2wSyokKxt+yYNMklQSXSnn4qKqQzBMLXSbtycqilcAQtjGlwzZY51pjFkwFRWqbWFWlsDKwV6hgj+5Ucc3VVg1P8wm15klLSbtpkn8J3/J6JhtIjJXZPNMf1hmNRM3mV9D6GP+FbP4Xz6nT36gR3X0TpDQzTsHiyv9jLLx3KZltyi4HPCDLiYRdwumeOS+oTAsqnPkkE2TvIIEcLPVFiVGSsdKzWawGTELFX6nTbO10kcBCpSdWLgTAHlcjqPUuldKd/NqtfU/8AxtMlZatrefMjaNfqapIZTLvPZH3dUb1HtYvHaz1xq6ztmhoik2LSA4rgVtf1PqDy2pUq1N39MrTHhtZ5c+MfT/eaLu11C3/eFYzUsd/y9RTeRna4FfJTp6lD/nAs8FKKz2umi4z4Kq8F8T/PPX2A6j2hLjZX0tUHD4vC+U6XqXU9K8EuJHIddej6Z111WBVbtPebLHLjyxb4Z45veNqfGQVcxxcMLg6TXTnC6lCvuMgyEpl/Z3FticogQ5VNqJ9xgFabZ2NAu1O3FlUx0/avBhXixyI4SLqtxaFa4Kl1jhFgxU1HDhZ3AuV1XMhViyyrfHpSGm8Jtxx2VhAFwqargPtQv0HVWtEuKyv1YcdrRKZ7G1WTVcGtGSV5vq/qzRaEGjoafuvaCN/E/wDlOS0WzF6RvuOx/lJ+potdtqV6YPYuC+Y6vrXWteS51V7KZttZYLkPrPL4qvcT5K0nBf1jf8jH8faRX07xA1NKT2eEDSqRuY5rh4OV8goUPeu15K2UtZrumOBo6iowA4DrKv8Aj3W0z/Jm9PqXuV6ZgsI57q6nq5dcLwel9baumR+rph7e8ZXr+ndU0HV6YfQqN3EXbNws7hY2mcrrsqB0GZV87hYrGGCmABdaWEQLpwVCDGEjx5VrgQPCqJAJBwiwlFR0NWKs0G62VCD8eFz9QfbuVhyeNsXH6hU2Mc6MLzVapufPK7XU6/xdOFwP3uMI4p1tWddTRkW7FdijAELz+mdDmw5dui8/FZc0VhWmqJaufVABgrqESyQuZqWS8kCyx4r3pVYKtik3W8qyqBPeFmc45wuydxjWqi8B0FNXaSJAWZjxMrZTq7oBEgpa1TVskACFZEtTR8bDCSS26lfiBsNkqNgiEaj7TwkpuE35QTZSbtAAuFsp2aLLNRIiy2N/bbK582mKmu87TAXLqlznfa6GpftkcrCRJAFyVpx+FkpcADEXSuaIPdaK1I0wHOVBMg2lbSsx0lDdXH/+le/6cyKLSWxbC8ZoKR91rovK9xomn2GlXhd5MeXqOgPi37SmYlHKhBIXVXLC7hF1mruhvZaSOFmr0t8iCs1zX68J6m6prH6saXTFzacQNli5Y+l+k36sirrHOknAPC9drujiu2QAHjBWPSa2voK4paynDf6XjCrzw7JVup9K6LTdNc6nRAIbYrwmgpVXVKjmNvOAvrzatDWaM0yQQ4LwNTRP6H1h+9hdpnGQ5dnDnJ283/Lxys1Hner9H6iaX6qow+yByVzui6xmk6kw1KQeHfH6K+l9RoN610v2KOoDWHJC4vT/AEvpOkVDqdTWbUe3BIgBGrld1E5McMPmOT1dpo0TULY3Ysut6e6M3X6IVHTPhZ+pR1rVM0+lYdoyV9A6H0+j07plOky5Aue6jkyxyrX/ABsc8MXk/wBJq+nagsguok/2Xb0ZcCDwV0tXRZVnErPTphnxC5eTCevQ4+S6000zJsrmgkwqWNgzKvZZZT1rV7BBsrmwbrOxxJVzTAW2LDKC922CFU50p3YwqzYGyKJGd5kpGn5eE9UgXiFW0yQsre2+M6GoLeFi1T/bZuOAJW17TtlZNRR91m0qLOxt5nqrtV1KmNNp93zsdqU+lRo+nGpUje0ST5XrNBpqGncLC/K26yjTradzTG0i4XVxySOblytunzLSsaKoe0B4acLgeow/WdVdUZpvbacbRlemdQPROtVIHuUHHHZdbf0vXt+Q2GMELryyxyx08zH7487b5Xn+memn6XRN1T3h5eAdo4VHV9MatJlNrYcXQCvT1tdotHSDfc3wLNC5vTmO6j1L36vxYD8QMBTOb5wsqpxXk5ZnOneoemtJV6PSBoiSwSSMleW1fprV9I1Z1fT6zmtBnaDcf+q+jU9RSpaXYXYHK5FWuzV1C2ncAwua5zT0ccbtj6F1ivqqQbqm/Jtt3denZDlyKHTtpBiBK6jQWNhZf/G65xhoKzvvdWg/FVuypqoz1BIN4K5usMU4m55XSqESQubr2nZMLHk8a4vKdTd8srmUY3wLyul1IXxK52kBNcNFyTYKuPrEZetBbtMhdXSuJYMpXaFwpgnMKaZzmP2kZWWdmUXOnWpHc26y6phExgrRSdIuUK12Lkx6yX64NYltQyLFZHmTZdLVMMmYhc6JBAXfhWOXVVBzt+Vpp1yyLrC55a4jlEVQ7OVrcdoldwc3sg4t/CrpVJaCbjsnfiYssG6mpUY0EAykpOki/wCFVUgm2AnoA7iVWukfrradhLcrWB8b5VGnZ8AVbXcWUycLjy7y02jFq3TUjhX6KgXkWWNjjUcSV6Ho+maYJW2vyM8stdtGt6bTr6AANh4HC8k6l7WqNEi44K+hEAWXmev6EM1bK7BErazUY4ZbrPoWB1VjYgSF7PSs2047LzHSqQfqG+Lr19BkAd1fBP1HPThsZCUjKtNspHxj+66rOnNjVW6eE8SJhQNE2uiJKiLpDTBFwsOr6fTrN2uaDeQeV1ADKjmAjCrW0b080dDXoHfRqGBwub1P9ZUpEP07nDvC9iaQINkj6IiNoU6sXuZevltajrqbppU6jT9INpayvHvNqE+ZX05+npuEOYDPhVt0TGzDB/ZFpTDHe3gun0dRpaxeynZeg0mr11Sz2lo7ALvfpGi+wKGgBwFF3GvVZmB5u5WhkHcE5Z2TtbaFN3VTGQjLm6vYBFkjWgG4VoF5RILVrGy4TCu2gNgqkGWiDdWTAWuPjHL0MyEkWhPPiEhkhI4y1iQSCJVLZBwrq0j7WaSs8tbbY+NG7cyErh3CVriBEKwXS/8ABYyVKTiJaSCslepraYhkvHaV2WtaREAqOog3FlU/pFjwnUqeqc+XUHGZvC4rWahlYgscD9L6m6iC3Eqs6NjhdrT+FW+k6jwB0D69LcQd0LRo9LraLmtp0jfuvbt0jGiBTEdosmGnbb4gR4R/9Eknkefp9M1eptWqOY08DldfSdOp6VgDGj7XQbRwmc0YSVKqDI4UcBZMTFkhKW9K0VxCpcTuJGFaTIVTm2JlRauRWQ2L5WLXMmiYMLbtwTlZ9e0O0rhCzz7i508jrGe4LqzoXSnajWe4WwG8q72BUdEE3sF6bp2j/R6YWgnKnHK60eWmfWaJjafxyO689WZ7dacL2D4dIIyvOdRohriYUWap4XfSug7eLK57TthYdM+DAK2SYyufOaq3N1bQ3K5lVha6QbLs6wbmLj6mWtN118V6RlGCo7c4nlK1u4gJdxlPSbGV1sGzSVpAG6y6Dj8DBXnaVQ0nyJhdjTagPbBWWeOu2mGaqsSPpHSumpEwrq9Hc2Qs+lBbVg5S3/qq+vS6ePbCr1jyWbQjppFIT2VOo+TwJhcUm8234GlpFxuF6TRsbRojuVytBTh3hdZhaBEro4/dsOTvpvYZbuCx9XpCtpANsuaZWqiS7AV7qYcQCLHlb2bjnl+a4vQdO8bnPbHZeqZuLBELJSohsELWyxnhbceOoy5Mt0XAm3KQtLTEyncCTZQgxdaVEVgEcIixkoAmUSbqKudm3TxCYROUkz9o27JxOhcAJhJkI7uEEWnIrja6102RIyohKhchTeyocrtpJQNIkmCpXFcNOAmDTCf2oTBlplLR7AMG3yoBCbsp4VJBgF1dtgJGt/CtiRcqojJU5pjOUtwFY6whVwSPKVVGatBdbKoGZKtq2PlV5b5WWTbEA4SrRcKgATHKuaQLTdR3FUzZB7K4Dcqg610W1CbCyuIsXRwMKNF0oJN5TieVaLEvN8KWIRgwoGygigkFB0kpiCheMoNW+YVRkCJlXHCRzeVN/pcVOkiyrJMXVmCZlCLqbKqKyQbqvVsJoOvaFcRAwg6HsLIz3Ss3FSvO6Sg46xsCzTK9EXRF5VVLRtpmeVK7hTaVnjhoZZbqt9T5rn9QYajCrfek35SV5cw8oy8PHquFS+NaOy3xLVhq/DUmBC1U6nxFsrm5GyjUAxBNlwNaQ0uE5wu9rSNhIyvNauo02OZXRwRnn0zNeJVrTeSqGD5+Fq2SBC66wjI74Gyto6h1N1iq6kpG2hVZuJl071GuH07i4RptmruAvK5+lqwNsrpUQZBXNlNOjG7dZjg2l57KimPdrSTgq0NmhPhDQMBeWi91yz9aW9OzQYG0WkdkHugrTtDaAAF1lqzGF0Y49Mbe27Q1/mGkyF2aYaRMZXmunOJ1JH+F6VoLQPK3wYZrWtsnbYXStd3Ttg5WsYUzYNjlEttZDaBEIgRyqiCROAliCrCblAiRdGlSqyDlSUxafwlLZwp0oIJwmj4wluBEqdpSVALYyoQMhEi9rlQAnKRwJsjtBE8ogDshmyDS4N0s7XeFDLQpwkZwZ+krhcpGTiVbtMSiFRYCVYbJW4TWWkZ31W/KrJgXVjm9krgIUVcY653OvZUExhX12rPHBWWUb4+IDuJVgYBeVUBDlcP2wUlU8CxKNgJQbP4RvxlNAtnlXNNsqm/KsYIvEqoVWtwhPysixwdaIRCpmFpulsHEFMRdK8bjIQYFoiQkdjEIkEDNkHXGUtKip3lJtJVhjbBQNrA3UqilwJN7Qo2Pyi6DaUjfiVPq2iQBMXXI6rVNMAB2bldYX+lxuuad1XTksvF/tVYiesdKoSBOFqcAWLBo/nQbuEHkLbSaTI4WOU/G3/rjaphFWw5VjP2hPrm7a8RASTAkLny/prGfWENbJK8vq3zVJK7vUKg5K8/WguMuXXwTphy0KJl0HC3OI2CBZZtMJOFrqlzKXxC0y9Rj4y1aQYHArKSA2V09QzeRCxPpy7iFWNTlP6LQeSQQfwu/pjupggLgtbtcIwF2OnPDjF7LPlnS+Ou2CG6WT2wm6SC+pdvKoYd7SDwul0dv84eDdcmM/G2V6dSqwspiFz6pINzZd59Jr6cRlcLV0/bqEGV1/Optz45bo9FG/qNV5naBAXp2n5DsuD0NrDVqAC4hegaJMYVYM872cQVY39qQNTCwWsZU5aYEKNzByoCSMqHcDcK4gSPCBPAUklTsQgaQmySCTHCeAeUpAlKnAgAqEGbXRBHKkQVKiRF+VM25TnKR9j5SqpR/pjlKhuISOzIKlUEu/sl3AmcJZvBRAuo32vRwAT2KtBiyFNo5TxGQtJGdpm4smN7INj6TE2Vs1TrKs3zhWvbKrAyCpq4oqgAFZXNDvtb6jAsxbBP2oya41leNo8qBxBuVpNMEKosgrOtZdiL3VjYJulaWxcH8Kzb2n8pxORg0wna6BCRpvfKtDZbZXGdoNmfKsBtcQkEgjun27hKaaBJJFkpkHCfcCI5S8IMjhdVxdXOAOcpHQEqcqt1krmj9yd1xCqOSCptaRW69ogKMFwDiUXSHeEBG+6g15hpAixWXWBuxwAtC0k7mrB1LUso6So51oCvaP1wdI0+49oMgOXYoMDuMLldLIrbngWJXfoUg2nuhZ3+2u+nneqt26nOQs7B8Lq7qtTdr3RfaYVLxDbWXPl61xvTjdSdBLTgLhuEumF1tcSHOkyuYGuL12cfWLnz9adK2QByMrRWbDboaSkQJKevNwlvs5OldcuMiIKxuMGFqquMzM/SpDZMqp4WRGskyVv0pNMtIsVSxscflXUzD4OEsruaVjHXpOky0rsdHH8/P2uFQfZdfplbZqGic2XL5k1y7xetGLLj9UpQ3eO911mGWrLrtOa+nfTg3C7L3HHLquH0vXNoa8T+x1iV6wO3QW4K8JUB0NSKjDMr1PRdU+vp5eCBxKWPR5d9uw2IuUwiZS9oTNstIxqwEBSRKXcFMq4iiQQUDINwoCVDcpgwcIwoQCkMWUmbJGBtwj5UJtCBbF5/CVioijrhD7UJkeFNVCOAVZF1YYIVbrELOrhTAKamNyhAIRomAQiKvi9ogJyRyqjUgLn6rqIogklabkY6tdUQU2OFw9F1hldxbugzhdZtYPbMomexcad0cKl2bJi+AkL5BSulSAXAKh7xuzZYOq9Q/S0iRc9lyNF1mrXqw9tvCzyrXHF6cRCrrWCqoVg9sH8Kyo+RCW5YrVlJTJJWlpkAlZqTSLjla2XATgyThM22CmgRhCw4VszwJlDdfwgJhAZ8Jp0jjMEKEk3FkS3wlghICSSJSOEwiSb2QJjKFRWZJISEJyZxykL4sVFq5strhKB8pRc6ZTU27rYU676V+I5xa268x1urU1NX2Wjm69PUBMgLlu0BdqDUPJVe9FOlHSdJ7TRK69eoKVA9oRoU2sbYLn9b1bdNo3kkScJZTWI9rzzz7mpLiq9TWgQMqUXe5T3xlZ65mqVyybyb/AI5mql0zhYw0gyFvqtJWYs2mV1Y3plY1aeRZNWYImUtAQRK0vbBiMqLe1Txy3kudDccqynTLjCDWGZ4WqjSIurt1C0ntWAQ2bTZXlvxmcKio6+YUb2a6kTGYK3Uaholrpx3XMomB+crrBjXU/tZ59Kncex6fqRX0zXhdCz2ry/p/U7XnTPdfIlemaIXTxXccvJNVmqaJj3S5vKvo6ZtFkNAH0rxJvFk0t7wtGe6AIiMKScKuflmVYBg8o/SpgLp/CAiU5+TbKkVMBLm6gJmMhA2vwmSXlGbKSHJZgoNDIRjnKIMqGOEKhSROEriSi4TFkJj8KFK7lIQQVbHKkjsp0vZIlvYpBub9K1omZQLZS0e1ZILVh1GmFWQR9LoBo4Te3OQiQbjgUukNFQOlzSDMBdqi3bT2yrfbCIbGLp0tqzZRpEQrA0FCAJEWU6u1b/HM6hom6hpkLmUtAKToAhd+rOOFlgE3Syq8ApANaP8ACtIJsoA3unYLySokVTUxFpV7LZuqAASrWAjBV41GS60IINPCMwSIWjJAYCUATIKO05uiUjAknlC5yi4ghJvm3KAjjAykdDhKabEQkaEqqbVOBCWL9075N5VRefwoulwCSTAT0yRblAnc1Cm75RKUFXWiYQ28p2i55QLvwrk/UgYDbFeJ69rTqte3SMPxm5Xpup61tCg4g3heS01H3dU/UPb8jJWPJm148L6vLRSohgNly3uO89l0NY/a3aucKbnPicrLjn60y6V7Zyqi35rWA6mSP7qs0xO6c8LaVNhqbMK4mBPKSmLwZlXFgcACPys7exGVtH5QcAf3VobtbiEGvByYKR9S8E2V3ZbR7oBWZ5tKNSsD9rK6pL1WOKbWyi6YXU07pELlUGkgGZK10qmysATZZ5za8W1z30Kja7BdpmQvZ9L6nR6hp2vDgHD9w7FeRDfcZA5WbQ6h3SeqNc/d7LrGCjhz1dJ5cNzb6S24kGyUssZwsek1zKjQ5pDmnC2OeDBGF17l8cncpDZ0yrmk2WdxG5X0xPKIKtEci6aDtshIREj6WkZ0IIHlQyRBRB8qAeUEm3ahyVIOVChQhAopDu7KaqIC6TEIXm4RH+UP6kjAHwjxEIScYUKVOABBRI5CE3TSCIQZAJTf0qH44Ch+oQNpNoQi6k4jCjj2QAMgyCFBBuq3GThFpvASPRaglUbPlK0vNlU0ElTZtcvSs0wboSPwrXGLAKtwUWKnfosIIVrXxaFQDAyr2R3VSlVjZ3XTnukkEQAiDGVcZiZ4S8okEixSus2/CZIYJCUtiY4RkRKXdaySgDiQQRdVkAhM6eEpsPKnaoSDhVxuH0nnnlKLKL3VToknaeySnV+doVlR3xMBZW/Eyns2/fLZwqKtYgETEKqpqNw7Lz/VurbQaFJ0vOSOEWz8LGf2ms1J1FVzAZg3Qpj2qccrLo6R2bn2KsqvhsArhzu8tOnHxm1J3uJOVna2c2VsEuurNoiVtLqFrbO74gws3yDpmy11riAsjrEEGQrx8Tk0U3SAribWWNr2tMlaW1RFkrBGEPkGDZVPqkNhUGr8ZBylLi6O63+WH0L3jcgyXuwptJWrS0i4iyd1IJu1roNFMC3Cm4Of9K8ANbBVDmiTtyufbZ09HVLpCXqNAupEtEnhZ9M8sqCV1m7atMysMv8AXLa53NOT0frh05NJ82OF7XRdSZXpiHSD/hfMdfT9rX1HDvK19N6rU09QS4xjK7JLP9o57N3VfTH1JcIWqhJEyvG0eu/AFwLvMr1fT9RTr6VlRjpa4LTDL6ZZ46bsKwWbZJkBWDgLaMKjQCg4RhMSQoTKZFEnKFpR3BpwgLiQkoWxN/7KEqTdAiSUlRBnsUpypBCG4KacKSQVYIIEhJcCMppRDFwbAgKABQN3DKaIT0W9FhKRJynOZSkjhKidgYAVb7AlE1BCqMuuCFNrSQm6TPCdjjulVxBRpGJCier1005CrDYmAmDm7QAVLRlX0jVitwthIWyLrRAA7pDEKdHKpDQPpMBfwExE2UAg2RIexY6VabtVY8KwftTTQF8G6BBU2w7KNgqJW49gk4VjolVukfSmnAe4AWVTjJTzGUjjJUVcJiSk/ceysc2/hKAJQstQRTN1yK3VaVHcxrXOPeLLp9QrChpHOIAMZK8TrtcQ0gC5UW3yCT9o6rrlV1RzAQAselnUasF0kSsN6tS67/TdL7bN5Fz/AIS5LMMVY91v9sNZZYa4l621SWs7eVzy8uqHlcuE3dtr/RmUy4mLwi6zUzCWmQi8AhafpMD3GSO6zOkArVXs5ZXScrbFlkQvgIN1G1t1VUPysqHklazHbO0roLBGVbSaDFsJKkCCGp2Ogg91dZtLWAkktsFqolrBIss1N57p5kZWWW61xaTULsJWtJdKqY/aAtdIBwlZ3pc7osbD2ldWgZAC5wEO8BbaL4GVz8m61nTgdcb7euIAu4SuYJBghdPrDvd1QMyQsHtlwBC7eP8A6Tbnz9dHRVCGXu1e59Nva7RnabTjyvBacEQ1et9MVttR9H8pTrIspvF7Km6WwFdMiVRSPKvBHIXVi5KIj+6BEYKJbZQgQmktiVAATZSIKl9xSqoBs5KLEwm3BTnwpVoA74peUzoBSgXSqoKIAhS4OURhMkiFHOgTKUmMrPV1AaCClvQmO6epXFNslY6utE25VFfUAiCVhqVxOVjlnXVx8Ta6rUJlpQGqe2xEFYhqWgXddRupY8xKlt8N/wCqLsqGs6IBWL9QxrlY6qDBCWy+WgV3DJ/KjNRUaZJnwsTtSAYJCIrh0QZRsfDrUdTJhxhaBtcJ/wBlx21IGVs09faIVzKssuPXbWcmJUExdRlQPbFpRyFf4y8QCEwEyUob5TmDhNJTgAf3TOS4TfuEICtxlJPEpy2LyqybqbVQpF1S4EOMWVjneErrnwova4r3F1j/AGVlMS6FW4gFWUjA3EIh3xxfUdbZptoXhdU8mpE8L1XqPUTU2ZuvJ1nTW7ox7p3qLdCwmsCRyvTUmlrJhcXpdOX3ExddwuinfsuX/Iu8tNuOdM2qqkjbuss1My6EKxl04Qpn5C6eM1DvrW7ZA25VZANuUbNElBxgyp/VMlan5uszmkSCFseN75mFneJJBytsaxyjM6kC3yFkqBs5W6qSGx3WRzRK3xZWE27iRylDC25Xpus+ieqdPPuUB79MctXmqnuUvjWpua7yFtcawmUoe4QINkQ6LgoNc1wuQiG7hAIU2L2vpvmCStjNS1hHZcuCDE4T/JwkcKLhKuZ2OkdaQbGyJ1m5sboXLBcQeyYGWxKj+OK+60Vf5jw7ISNHycALKMdtIBWllIPBc0p+HO0owXARdd3oxNLXB5/abLlaekN08rp6QinqGOJ+M3WOWXatdae6oO+EytTYMLDpXNc1pGHBbmiOF243ccWc7WEWtKWwCsGEriAtGQTACBcoYJ8JXWKmqgWIuFAe2AoLoECCpWD82QJsjwpBFklAX2CrfWawEuMQE5bbKw6+k6tRLBIJ7I9Oeq6/U6Qb8XAnwsVXW7xK5Y6LV90n3XA8iF0aPT3QA4k/hZ2V1YzGKnudUEjCxvo198Af3XepaSGwYsrm0GAwRKJhKq80njyjtJrHn45+0auk1dNm4SXcgcL1NTTtgkCCqDSMSEXHRTmteQrazW0oHsPcfDTKfT6rWamptNF9PwQQvTlon5NCdumZYhoU6h/yWOENLqnmAbcqHTamnaHEeF3yGtNmparwwSQjUh/yVx2GqxkuBVtPWECHEq91Vhf+1VvZRdlv9lHTTumZ1NtIg7xI8rraXXt1DZbleZf0+m+qXhzhPC7vTNJ7VMQCJ7qsf/GHJJp12m0wmm9krZAuZR+UrVzaRzTlKSRZOXeUpdOUAjj3KR3xumMEqpzrwQoqoDhMmbKp2bqwkGSq3EYlTVwrGXWh4a2kSbWVLFR1GuKemcSeEeQ73dPI9Zf71YgGwK4NSN1l1NS8vc491yz++6WCsnV6U4A4+11qtmLi6GptqDsutUMsuubmn++23H45Wped5hVU6sOEyrtS3dPhZAThbYzpGV7dQPD224Sk8SsNKu5hk3GIV/vNImbqfjsfSyoNoMKp7fjKU1txibLPWrhogFXjjU2ke6TKopU6+t1QoaamXuPZJWr2gZK+peh/T9LQdMbq6zP+IrDcSeBwurjwc3Lnp68gEEESCufq+i9N1rXCvpabi4fuLbrpHsljgldDi3XjdX/DrpdVjvZdUpvOHbphcPVfw01NKnu02r9x/wD0kR/lfTQIKO4ieUrIqZ18Q13prq/TX/ztOagj9zLrnl4YC1zS13lffS2nUb82gjyF5/rPozpvVGbmsFKqLhzf/Ki4ba4cv9vkLTAPZNsm4XU6z6X6j0atuDTVoDLgFywHOMCfpZZTTfHKZFcS0rXQeGi5yswBNnZCYHaQos2qWx0qJh0grbRrAuAIXKZVAxK3UXiRBXPli3xr2fSNSKlIN5bZd5h3ALxPSdYylW2mb8r1+mq7qYJ5XRw5bmq5+bHV3GwI7LJQZxdPYixuuhy6VgD3ITOAJUNzhMYFilTVWlK8AGZsrOYSlpOVOlSkEEQpIxeVHfHhLMOwhQkWSubLRKc4SvEiyk1FSkJJhVwGhaYETKrewOshcqtjhNgmcQbFVup1GYVVSsWD5DCW1a2uJI5SPPAwsr9azbyCqxq2k5U3JpMKd4AcnYTKyurNfhMytAuo3ur+bpofcExhZqo3Dm6tOoaRhBtRtTDTKdE6YXUyWwLFFunc+wyuiygC6YWmlp9puEfO1Xm0yaTpu0B1SCey6bWhsCFY1oAhBzYGVcx05ss7lULUC0gZMqSbQboOJmyEIWzF0hBBTuJgJCZSqoBIInlLabpjBgYSXEyElK3EzwVUSJs1XOHYQkLTZJXkO2zbLidcduo7G2OV2yA1hnK8p1ivur7W8WKjO9HhN1xK4IJHhc6oy8z+F0azhk9liqbSngeRaVUsvK6VLXE04dwuRiyG9xteFVwmSZnY6bq4JjhZ6rgDZZQ8gwhJlEw0LnszqkG2UzK2ZyqpJdhISdxjCv5R9L6jycFIZcJcbJC6Bc2Wnp+i1PU9UzTaZhO7LuAqmKbm2elekP6x12m2D7VIhznRI8BfaaVIUKTabRDWiAuP6Z9O0egaMtBD6z7vfGV2wDycrok1HHnlu7PMKQCZCkKAkHsqQhahhEl02wiQEAsfFCDFkwFsoxaEgpq0KeopGnVYHNNiCvF9U9JM09R1XTNBpnLTwvckYSkBwgiyjPCZTTTDO43p8Z13S306hgLlPpuadpF19R690RzZrUW7mG5AGF4vV6Jr6hc1q5LbhdV245TObcNjiw3N1poVXbvpStpHhxJbhVBr2XEwn1kc3HV09YsfuXt+k6xmp07QHDeLEL5vTqOpnm/ddfp/U6mk1DKjR9juFElxu1Zf7TT6S1xBsYVwOJWDTaqnqaLajD+4THZaGv7FdGOTluLQR2QIBHlBjhyUSLyr2zLkWNwlk3T7ZMoHwjR7JExyo5nhM2QcZUL9tjcpKJAIukEtwnmyGclTYosT+UXNBbdSL2U+0jIWzlI+ix5uFbINkoMFCpbGZ+ioRem2fIVX6DTzZpB+1teQQEm29sKauZVQNHQH9ISu0VJzrWC04GFAED6rMNFTbA2f5V7NPTafiArNzQL5U5kFMrlaJa1pB2oF44RkoES5BRB9qBwwUIslkwg+hI2yQVIkZukJjmyIk3U7GkMnnCUyBco7SCkM8FKqkSbpXbpkKGwhSRiUjC5EzZGDAtZNHCBdDSjWuxao1ldtHTuJ4C8Vq64e5zjkmV1+s6wkljX25Xmq9QRJN1lf9qqdRVWq7jICyVXfIWspVqEuslJk+VtjNIyqN+Z7KGmd/hBxaxvlLSdUrVGsosc95MBrRMq5C3J6teGi4yhIi2V6Pp/o3qmtpNqOp7A7APH2u7R/h0IBqagA8iFUxtRc8Y+eyGgzkq6h0/Wa6G6ag95PYL6no/Q3S9MWueze8Gb3C72n0Gn0YijSa0eArnGyy5Z+PmXTv4da/VFr9VVbTpngZX0HpHQNH0WgKdCmC6LvIuV1vKhE3WkmmOWVpcmUcFSPKOTZNBiIyhhMbhLBAumByEFG3wpBuEBBZEkBKJwiWg/aAB7oROCnFwgLXQC8EESFyNb6c0ercajAaT/+3BXWn5JjCm4y+qxys8eF1vpfWtcfZY2o3i65Gp9P6qmflpnNPMCV9QEjChIcMLG8GP42nPk+Ru6U4kgNII4jCqOjrUSSabi0cwvrpo0n5YD+FP09DbBptj6S/g/9V/yL/T5v0LqGp0uqFOox3suPbC9o1wd8m8rbX0OlNMkUWSB2XIaSx5HASuHwczmfbY15BE4VwLScrKyo02m6tBmO6JkLivEgokg/arDoCO7lXKiwXfaBEBQyOJR3EhMlRuLIm4wmLRKGQpVKXIxcIG+U1u6BykqK/oKQZT5KDmxykpXDiIiQpwrBYXKUhSey4GEObBEi2UY+Mo0A2ki4UiEwcSLo7ZEoBQEDblHcZwiPKYJKBvwncyMJCkZCACfKkgWChmUCJMhLShJsq5l1kxBiyWIdlSYTHF0Nt5RcIcLyiUv0xHxscLn9S1rdHpnOF7cLVUq7W3XP1OhqaykdomeEXd6Lz143U6l+oe55s08LFUJicru67oXUACKNEx/suez011nUOgUHBXjgWXJi5L3Nb8jAVW/efiCScAL2Oi/hzrdS0O1FUME45Xsul+jOl9NYP5Ie4cu7raYVhlyyePnvSPRnUequZUqD2aJIknMeF9E6J6R6f0f5ge5VGHO4XdbTDAGtaA0YhMLGCFpJIxyztQthvxQvMlOLIZVIA3CbKDSRZG58JkNsKFpIQieUbgoCATwh+0ymF7JSCJBwgGFrFQzyhYiYKIKAAkGUwMoA+FASThAQiUEZUlACJCGM3TROUAEALFH8KG8KBIJeFLBAZhQ3QEyLIQcpmwfBQcgyubIhcDUsLKzm9ivQRNpXD1rXM1Li7krLl8bcPrKDDpButFOpP2qXAD5QkLy265rdOnW28O8ptxxKxN1BcRK0h4cAqmSLi0B9spg/ws/5VrXYWkrOxYTylENwFN8lQ3CrZaQkGbKsjsnuBKU/SVVAFx5UmeJUIsi1SpDGCEpM8QEfspIugxi98IfSmQiBBQALfirBgIfahsMoICAUI4ymhCDNkGG0jlK5piQrDxKV54CDVFpykgxJVrsqp0CYN1N/8VE3DbeyqImOU8EthQtB5ghRaoojkKurVDBhCrVLD3VBl7ge/dRbpR9vuGThdXpDQd5jBhc2D7a7HRWEadzjyVrxf9mPNdYt4bTLv2A/hWbGjDR/ZDlSJXY4khwwUNsnKYxhAWGEEgtlGbogSL4Q23QEtOFOcIhHITBC2bwjHdEjjhTjCAAESpAOSjChEoAbb5RF1PtSeyAJ7oA5UhAtsgCSlAgzyiL2RiyAEGZRBlAHupNphIAc3RypM8KC10wGCEVCAboEEWBQBlCSLwojM2SBSTM7Uco4N0pkFAGAVyepN+YXVEm+Auf1JuFGc3GnH/2cy5Cre2FcG3SuaQTay5Mo7YzOsVZTrEBI4RlJsgLPxToU6ocrWv4mVzWFwNldTrXurmf9ouLeHRZNuBVDHh0KzeB5WsyZXE+cKXGcJA7KJM8J7BubYQ2yk3EGDZNvESgxgAXQdG2QiXAwlMBAFpv/AOFJiZSNMulPmQg0JaQLqQBZTbLVAQEAwgWUxhQJSSMYSJDJKB7yhJnCUm6DB8nhVxF4VhfdUvqhvKm3Sxc5o+lmrVgLNVbq0yEjQXXKxuTSRAC4gkyrGt+SVrDKvDUpBajrgALu9Nbt0Y+1wyyQIC9Bop/SsB7XXTw+ubm8Xj/CJthSwFlAOV1OVPtEKRKFighBJQM4UESoSmAgg3KaYQJkXRlBpdFCCbShcJEYqYUFwjcBMFwZhENQmykEXBQEJKAJm5QCZAQicIAkFMTZAAdkAIEI4CChCAl1HGAFJspugICSIwpwpJOEZ7oBQLo7RNkDcqbuEgJzdAkGyihCDGeFj6gz+VK1XCza6+nJ7XU5eKw/7OUz90IPBa6+EafyMlWOE3XNp17Z3MDhZVGnFls2iEjqSi4bVMmU045QLAMFa/bg3VTqZNgEvg/pUC5uCrGVjyiWGIhIaZJS1YOl4qjup7kmxWYsIwgC5uQSnujUb2vH5TBwWJtUFWsqA8q5knS++VPtV7+zvwh7l4OU9lpae4RZeb3Ve611AYNzdPYq0cypMJN4xKBqAHKCWykMykNWTZVuqwJU7PVWudtvMqh+o7wCkLw4WVTmkuulcl44mqV3EKglzsmytcIaFALYWV2uaikNlOGEGf8ACs2AjCvaywRMdi0jafdWtpCMqwM+OPynDPpa44M7kqI2gDhdnSNI07eVyH2cBkLsaa1BsLfiklc/LelvKY4CGRZQXWzAVALKEgiJUFrIIAEwAiyBAPKAEGEwMtlCLposggBxdMDIQypEJAUUoF0XtvlMDChE+EoPdMDKAXmFNsqP7oCxygJcFEDmVCQeEMHFkASZKkyhM8IxLbIAYKkyhgXRtEwgJCHEoo3iAkAFwpZC4UumAiCpE3B/CPN1JDTHdIAQs2sltArU6Jws2qG6g6SEr4vH1ymSY4K0DCzU5nK0jAXO6ihoOLKRIRtJ4QJNoQA2yISuZCsBk4Ru6wCek2qRTtdVlgHK1bRPKhph3CPk/pkLJMJS3blayyOEr2So+T+2LYCTKntXkGy0GmUwaGi6Xyr6ZAx243nsnAeDdaQ3lAtnKPkWqCHG/Ka9icqwNh0cJwwG0KtJ2zljnYwk9t3dbQALJC2ThFhys4BBulJLXeFoczbdVOAsFFmlxWcpXHhWQQVNodwpsVtWPkACrWgYAUayMBO1rgcWRILRawGBwrWMCNJt5IVgbdaY4/rK5J+4JIgkK0iAq3AtEwqJU5pH912dKD+nb9Lh1HEFdvTf/LMvwr4/WfLOlpamgj6UBUBvm62c4GBwj+EDm6KCD/ZE5lQC6FkwN4UR3jEShkoCZwiTCgSkWugDaMoieUoAIRBgxygJnCItlSCoLoBZmFEQQpZAQHuhMKRdGO6Agwh+VJEWUAAQAMFEXCkIR+EAQUZAUCBsUATlKc5R4UKAEAjyoPKIF0s3SBjlZtU3+S5XmVRq7adxylfFY+uXTEC6tnlVsBIlWsFlzurZSVAJGVHN5QsEGYJpjCrLrwrAfCcKwxBhGCBlA3CIJFuFcZ0oaHXJULQQmi8hEssjQ2qLOEuwh1hKukZUmQUtHtUGHkKQArJUAl1wjQ2SxGFNsXVkCYSmwS0eyOPKEymgkJXBylYRPIWcs+R8K/wMqlxvhTe1Yk5Sgw/7VgMJgO6hYAOmFY2QIUbIPcJxZ1xZVE2i0QEWgkzKYNETM+FIVs9jBcLpHh0RNgiTFu6qLjfsinFVUbhldjQmdIyRgLjVII8rqdMqF+mjkGFXH6jln+rfaPKlgEoae8JgN2St3MnhRGFIEIIsmcWRiVDgQpKAgEKSO6mQoEwMjhAz2UtlSUBIJF7KRCOQjgIATwlIJwmCMFAITHCkYtdML5Q5QAB8XUzyhzdTlARSREIzFoQJB4QBAgKD5BAfShNkAUYCWfCN+yAIQypwiDKAGShzZQlLcGxQZjPZZtYdtE9loBJWPXvIaB3U5eHj6yNmAQLFMCJIQYDGUwAH0ud1EOICBBwU24YUJ4hBlE7rKwBKZIBhSU4VWNuYTRISNF5TGWmQFcZ0WmLEKXCkE35QMymkwgm4Uc0C6nZPwjQ2rEKGIsmAEoFubpGrkzdQnum23UgZSqoXdJ7IGUDnwgSRgqaqQHSBhZ3E7leX2M5VLjudKmxeJQ2VY25QbjyEzWzdTIu04aAYTt7EITbCIDgrjOjBUCbsldHZPRFeYKqc6AVY+SMXVTyQ1SqM782W/o9X51Gd7rAZPZHS1/0+pYSYBMIxuqM5vF6TJTWiAlBBAIRDiupxeCBHKkEqG6GEEnhQktjkKSIUtgpg0ghQeENslAGCgGmDhA2UzyogIEReVDkKA8ICSO6k38KEBQGEBBMJZuUQ4I2KAQhEWCmD5UlAQWRm0oeUMoCboKbKWBKICB6G6EZlAZIKLcwkEBspIU8QhygDPEIEWwoZmUbxdALvjwufrC17lvc2y5lW7yeynK9NMPSNFsGU82ug0o2KxdBCLyoSYTQpaLJAsuTCSUNpiyLQRlOA8EIk8ylBlGRiFURYIMHyi64EoNPCjszwqSaxwjCinynwmSTeyAMqSGlSJJKRpHyQPJQ/aEYkZUmr/CB7pj2SFpnNlK/CPCQNGVYfihMtsElEAgzCsEwpYROE4LeEC1GtB5TwQLoBom6sghsxZVIi0swJCU3RJEx3SzkIonZXWvyqHmc2VzvCoe2bqK0ih4VFQw2exWhwAdKqqiGmeVGlvR6Sp7+nY7ghXrk9E1IdTdQP9OF1+LLrwu44s5rLQiECIBQmCjukGQqZpeFL8o8IfaYNflD7Q3cSiPuUggiUSeyXcJgo+UwkoTAlNaEIBwgBM4UyoMwjCA//2Q",
                Fingerprints = fingerprints


            };
            #endregion

            applicationForm = new ApplicationForm()
            {
                Applicant = applicant,
                ApplicationData = applicationData,
                BiometricData = biometricData,

            };
            return applicationForm;

        }

        public static List<string> Validate(object obj)
        {
            List<string> errorList = new List<string>();
            var context = new ValidationContext(obj, serviceProvider: null, items: null);
            var results = new List<ValidationResult>();
            var isValid = Validator.TryValidateObject(obj, context, results, true);
            if (!isValid)
                foreach (var validationResult in results)
                    errorList.Add(validationResult.ErrorMessage.ToString());
            foreach (var prop in obj.GetType().GetProperties())
            {

                if (prop.PropertyType == typeof(string) || prop.PropertyType.IsValueType) continue;
                var value = prop.GetValue(obj);
                if (value == null) continue;
                var isEnumerable = value as IEnumerable;
                if (isEnumerable == null)
                    Validate(value);
                else
                    foreach (var nestedModel in isEnumerable)
                        Validate(nestedModel);
            }
            return errorList;
        }

        static bool ValidateXmlWithXsd(string xmlPath, string xsdPath)
        {
            // Load the XML file and the XSD schema
            bool isValid = true;
            XmlDocument xml = new XmlDocument();
            xml.Load(xmlPath);
            XmlSchemaSet schemaSet = new XmlSchemaSet();
            schemaSet.Add(null, xsdPath);

            // Create a validation event handler
            ValidationEventHandler eventHandler = (sender, e) =>
            {
                // Print the validation error
                Console.WriteLine("Validation error: " + e.Message);
                isValid = false;
            };

            // Validate the XML document against the schema
            xml.Schemas = schemaSet;
            xml.Validate(eventHandler);

            // Return true if the XML is valid, otherwise return false
            return isValid;
        }

    }
}
