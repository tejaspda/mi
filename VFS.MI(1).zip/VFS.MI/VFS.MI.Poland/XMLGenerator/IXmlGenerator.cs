﻿namespace VFS.MI.Poland.XMLGenerator
{
    public interface IXmlGenerator
    {
        public XMLResponse GetPolandXML(Contract.V1.SQS.BoltSqsData? boltSqsData);
    }
}
