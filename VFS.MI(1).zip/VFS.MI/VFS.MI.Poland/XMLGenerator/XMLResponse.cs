﻿namespace VFS.MI.Poland.XMLGenerator
{
    public class XMLResponse
    {
        public List<string> errorList { get; set; }
        public bool isError { get; set; }
        public string XML { get; set; }
    }
}