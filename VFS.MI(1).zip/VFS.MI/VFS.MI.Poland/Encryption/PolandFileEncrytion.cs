﻿using System.Security.Cryptography;
using System.Text;
using VFS.MI.Poland.DAL;

namespace VFS.MI.Poland.Encryption
{
    public class PolandFileEncrytion : IPolandFileEncryption
    {
        CspParameters cspp = new CspParameters();
        RSACryptoServiceProvider rsa;

        string _privateKey;
        string _publicKey;

        private IDAL _dal;

        public PolandFileEncrytion(IDAL dal)
        {
            _dal = dal;
        }

        public byte[] computeSHA(string filename)
        {
            FileStream stream = File.OpenRead(filename);
            byte[] fileBytes = new byte[stream.Length];

            stream.Read(fileBytes, 0, fileBytes.Length);
            stream.Close();

            byte[] data = new byte[4];
            byte[] result;
            SHA512 shaM = new SHA512Managed();
            result = shaM.ComputeHash(fileBytes);

            return result;
        }




        public void generateKeys()
        {

            rsa = new RSACryptoServiceProvider();
            _privateKey = rsa.ToXmlString(true);
            _publicKey = rsa.ToXmlString(false);

            StreamWriter sw = new StreamWriter(@"D:\TmpMIEncryption\private.txt", false);
            sw.Write(rsa.ToXmlString(true));

            sw.Close();

            StreamWriter sw1 = new StreamWriter(@"D:\TmpMIEncryption\public.txt", false);
            sw1.Write(rsa.ToXmlString(false));

            sw1.Close();
        }



        public string EncryptFile(string xmlContent, string aurn, string MissionCode, string CountryCode, string VacCode)
        {
            string fileName = aurn.Replace("/", "");

            string xmlFilesFolderPath = Directory.GetCurrentDirectory() + "\\TempFiles\\XmlFiles\\";
            string EncrFolder = Directory.GetCurrentDirectory() + "\\TempFiles\\EncryptedFiles\\";

            string PubKeyDesc = _dal.GetEncryptionKey(MissionCode,CountryCode,VacCode);

            if (!Directory.Exists(xmlFilesFolderPath))
            {
                Directory.CreateDirectory(xmlFilesFolderPath);
            }

            if (!Directory.Exists(EncrFolder))
            {
                Directory.CreateDirectory(EncrFolder);
            }

            string inputXmlFileName = xmlFilesFolderPath + fileName + ".xml";
            File.WriteAllText(inputXmlFileName, xmlContent);
            string outFile = string.Empty;
            string KeyName = "KeyContainerName";
            //PubKeyDesc = "<RSAKeyValue><Modulus>tNbeCzI8p47/FkgDZe0MrHUitGQ+925SSG8c3RVf3uipIeOWvGBexd0p/esVx2Nmga0bmBTMEpzUtM4k0nc63iFs62KgZWtIJqGjMOjW24a+jTqSzeMx5BTJsUNkAfDyXiScUbLISpeYeCZHrJdMkq07Hz1zznu7TAPuAyOpuZk=</Modulus><Exponent>AQAB</Exponent></RSAKeyValue>";


            // Create instance of Rijndael for 
            // symetric encryption of the data.
            RijndaelManaged rjndl = new RijndaelManaged();
            rjndl.KeySize = 256;
            rjndl.BlockSize = 128;
            // this is in accordance with decrypt
            rjndl.IV = new byte[16];
            //end

            rjndl.Mode = CipherMode.CBC;
            ICryptoTransform transform = rjndl.CreateEncryptor();


            //generateKeys();

            //cspp.KeyContainerName = keyName;
            //rsa = new RSACryptoServiceProvider(cspp);


            //rsa.FromXmlString(_publicKey);


            //StreamReader sr = new StreamReader(PubKeyFile); //commented by aisha bachani cr2364
            CspParameters cspp = new CspParameters();
            RSACryptoServiceProvider rsa;

            cspp.KeyContainerName = KeyName;      // keyName ashley PR 157;
                                                  //Added and Modified by Mitalee on 16-Sep-2014 for CR 2281 start
                                                  //rsa = new RSACryptoServiceProvider(cspp);
            cspp.Flags = CspProviderFlags.UseMachineKeyStore;
            rsa = new RSACryptoServiceProvider(1024, cspp);
            //Added and Modified by Mitalee on 16-Sep-2014 for CR 2281 end
            //string keytxt = sr.ReadToEnd();//commented by aisha bachani cr2364
            // rsa.FromXmlString(keytxt);//commented by aisha bachani cr2364
            rsa.FromXmlString(PubKeyDesc); //Added by aisha bachani cr2364
            rsa.PersistKeyInCsp = true;
            Log(String.Format("Private Key length: {0} bits", rsa.KeySize));

            //sr.Close();//commented by aisha bachani cr2364


            //FileStream stream = File.OpenRead(inputXmlFileName);
            //byte[] fileBytes = new byte[stream.Length];

            //stream.Read(fileBytes, 0, fileBytes.Length);
            //stream.Close();


            byte[] keyEncrypted = rsa.Encrypt(rjndl.Key, true);

            // Create byte arrays to contain 
            // the length values of the key and IV. 
            byte[] LenK = new byte[4];
            byte[] LenIV = new byte[4];
            byte[] SHALEN = new byte[4];
            byte[] FileLEN = new byte[4];
            //lenght of encrpyted key
            int lKey = keyEncrypted.Length;
            LenK = BitConverter.GetBytes(lKey);

            ////len of encrpted rijental key
            //int lIV = rjndl.Key.Length;
            //LenIV = BitConverter.GetBytes(lIV);

            byte[] SHA = computeSHA(inputXmlFileName);
            byte[] SHAencrpt = rsa.Encrypt(SHA, true);


            //len of encrpted SHA key
            int s = SHAencrpt.Length;
            SHALEN = BitConverter.GetBytes(s);


            byte[] file = Encoding.ASCII.GetBytes(inputXmlFileName);

            byte[] Fileenc = rsa.Encrypt(file, true);

            //len of encrpted SHA key
            int len = Fileenc.Length;
            FileLEN = BitConverter.GetBytes(len);


            // Write the following to the FileStream 
            // for the encrypted file (outFs): 
            // - length of the key 
            // - length of the IV 
            // - ecrypted key 
            // - the IV 
            // - the encrypted cipher content 

            int startFileName = inputXmlFileName.LastIndexOf("\\") + 1;
            // Change the file's extension to ".enc" 

            DirectoryInfo diInfo = new DirectoryInfo(EncrFolder);//Web Config
            if (!Directory.Exists(EncrFolder))//Web Config
            {
                Directory.CreateDirectory(EncrFolder);//Web Config
            }

            outFile = EncrFolder + inputXmlFileName.Substring(startFileName, inputXmlFileName.LastIndexOf(".") - startFileName) + ".esp";


            using (FileStream outFs = new FileStream(outFile, FileMode.Create))
            {

                outFs.Write(LenK, 0, 4);
                // outFs.Write(LenIV, 0, 4);
                outFs.Write(keyEncrypted, 0, lKey);

                outFs.Write(SHALEN, 0, 4);
                // outFs.Write(LenIV, 0, 4);
                outFs.Write(SHAencrpt, 0, s);

                outFs.Write(FileLEN, 0, 4);
                // outFs.Write(LenIV, 0, 4);
                outFs.Write(Fileenc, 0, len);

                // outFs.Write(rjndl.IV, 0, lIV);

                // Now write the cipher text using 
                // a CryptoStream for encrypting. 
                using (CryptoStream outStreamEncrypted = new CryptoStream(outFs, transform, CryptoStreamMode.Write))
                {

                    // By encrypting a chunk at 
                    // a time, you can save memory 
                    // and accommodate large files. 
                    int count = 0;
                    int offset = 0;

                    // blockSizeBytes can be any arbitrary size. 
                    int blockSizeBytes = rjndl.BlockSize / 8;
                    byte[] data = new byte[blockSizeBytes];
                    int bytesRead = 0;

                    using (FileStream inFs = new FileStream(inputXmlFileName, FileMode.Open))
                    {
                        do
                        {
                            count = inFs.Read(data, 0, blockSizeBytes);
                            offset += count;
                            outStreamEncrypted.Write(data, 0, count);
                            bytesRead += blockSizeBytes;
                        }
                        while (count > 0);
                        inFs.Close();
                    }
                    outStreamEncrypted.FlushFinalBlock();
                    outStreamEncrypted.Close();
                }
                outFs.Close();
                File.Delete(inputXmlFileName);
            }
            return outFile;
        }


        public void DecryptNistFile(string PrivateKeyFile, string inFile, string outFile, string KeyName)
        {
            // Use FileStream objects to read the encrypted file (inFs) and save the decrypted file (outFs).
            using (FileStream inFs = new FileStream(inFile, FileMode.Open))
            {
                // Create byte arrays to get the length of the encrypted key.
                // These values were stored as 4 bytes each at the beginning of the encrypted package.
                byte[] LenK = new byte[4];     // AES key length

                inFs.Seek(0, SeekOrigin.Begin);
                inFs.Read(LenK, 0, LenK.Length);

                // Convert the lengths to integer values.
                int lenK = BitConverter.ToInt32(LenK, 0);
                Log(String.Format("AES header length: {0} bytes", lenK));

                // Create the byte array for the encrypted Rijndael key
                byte[] KeyEncrypted = new byte[lenK];

                // Extract the key starting from index 4 after the length value.
                inFs.Seek(4, SeekOrigin.Begin);
                inFs.Read(KeyEncrypted, 0, KeyEncrypted.Length);

                byte[] LenSha = new byte[4];   // SHA length

                inFs.Seek(4 + lenK, SeekOrigin.Begin);
                inFs.Read(LenSha, 0, LenSha.Length);

                // Convert the lengths to integer values.
                int lenSha = BitConverter.ToInt32(LenSha, 0);
                Log(String.Format("SHA header length: {0} bytes", lenSha));

                // Create the byte array for the SHA (SHA512)
                byte[] ShaEncrypted = new byte[lenSha];

                // Extract the SHA starting from index 4 + lenK + 4 after the length value.
                inFs.Seek(4 + lenK + 4, SeekOrigin.Begin);
                inFs.Read(ShaEncrypted, 0, ShaEncrypted.Length);

                byte[] LenFileName = new byte[4];     // FileName length

                inFs.Seek(4 + lenK + 4 + lenSha, SeekOrigin.Begin);
                inFs.Read(LenFileName, 0, LenFileName.Length);

                // Convert the lengths to integer values.
                int lenFileName = BitConverter.ToInt32(LenFileName, 0);
                Log(String.Format("Filename header length: {0} bytes", lenFileName));

                // Create the byte array for the FileName
                byte[] FileName = new byte[lenFileName];

                // Extract the FileName starting from index 4 + lenK + 4 + lenSha + 4 after the length value.
                inFs.Seek(4 + lenK + 4 + lenSha + 4, SeekOrigin.Begin);
                inFs.Read(FileName, 0, FileName.Length);

                // Determine the start postition of the ciphter text (startC) and its length(lenC).
                int startC = 4 + lenK + 4 + lenSha + 4 + lenFileName;  // lenK + lenIV + 8;
                int lenC = (int)inFs.Length - startC;
                Log(String.Format("Length of encrypted NIST data: {0} bytes", lenC));

                // Create the byte arrays for the encrypted Rijndael key, the IV, and the cipher text.
                byte[] IV = new byte[16];

                // Import the private (and public) key
                //StreamReader sr = new StreamReader(PrivateKeyFile);

                //CspParameters cspp = new CspParameters();
                //RSACryptoServiceProvider rsa;

                //cspp.KeyContainerName = "Key01";
                //rsa = new RSACryptoServiceProvider(cspp);
                //string keytxt = sr.ReadToEnd();
                //rsa.FromXmlString(keytxt);
                //rsa.PersistKeyInCsp = true;
                //Log(String.Format("Private Key length: {0} bits", rsa.KeySize));

                //sr.Close();




                cspp.KeyContainerName = KeyName;

                rsa = new RSACryptoServiceProvider(cspp);

                //rsa.FromXmlString(_privateKey);
                rsa.FromXmlString(PrivateKeyFile);

                rsa.PersistKeyInCsp = true;

                //byte[] FilenameDecrypted = rsa.Decrypt(FileName, true);
                //Log("Original filename: " + UTF8Encoding.UTF8.GetString(FilenameDecrypted));

                byte[] ShaDecrypted = rsa.Decrypt(ShaEncrypted, true);
                Log(String.Format("Decrypted SHA length: {0} bits", ShaDecrypted.Length * 8));

                // Use RSACryptoServiceProvider to decrypt the Rijndael key.
                byte[] KeyDecrypted = rsa.Decrypt(KeyEncrypted, true);
                Log(String.Format("Decrypted AES key length: {0} bits", KeyDecrypted.Length * 8));

                // Create instance of Rijndael for symetric decryption of the data.
                RijndaelManaged rjndl = new RijndaelManaged();
                rjndl.KeySize = 256;
                rjndl.BlockSize = 128; // Must match the bitlength of IV        // 256;
                rjndl.Mode = CipherMode.CBC;

                // Decrypt the key.
                ICryptoTransform transform = rjndl.CreateDecryptor(KeyDecrypted, IV);

                // Decrypt the cipher text from from the FileSteam of the encrypted
                // file (inFs) into the FileStream for the decrypted file (outFs).
                using (FileStream outFs = new FileStream(outFile, FileMode.Create))
                {
                    int count = 0;
                    int offset = 0;

                    // blockSizeBytes can be any arbitrary size.
                    int blockSizeBytes = rjndl.BlockSize / 8;
                    byte[] data = new byte[blockSizeBytes];

                    // Start at the beginning of the cipher text.
                    inFs.Seek(startC, SeekOrigin.Begin);
                    using (CryptoStream outStreamDecrypted = new CryptoStream(outFs, transform, CryptoStreamMode.Write))
                    {
                        do
                        {
                            count = inFs.Read(data, 0, blockSizeBytes);
                            offset += count;
                            outStreamDecrypted.Write(data, 0, count);

                        }
                        while (count > 0);

                        outStreamDecrypted.FlushFinalBlock();
                        outStreamDecrypted.Close();
                    }
                    outFs.Close();
                }
                inFs.Close();

                if (!ValidateSha(ShaDecrypted, outFile))
                    Log("NIST FILE HAS BEEN TAMPERED WITH! (incorrect signature)");
            }
        }


        bool ValidateSha(byte[] sha512, string filename)
        {
            byte[] bytes;
            using (FileStream inFs = new FileStream(filename, FileMode.Open))
            {
                bytes = new byte[inFs.Length];
                inFs.Read(bytes, 0, (int)inFs.Length);
                inFs.Close();
            }
            byte[] hash = (new SHA512Managed()).ComputeHash(bytes);
            if (sha512.Length != hash.Length)
                return false;
            for (int i = 0; i < sha512.Length; i++)
                if (sha512[i] != hash[i])
                    return false;
            return true;
        }


        void Log(string message)
        {
            Console.WriteLine(message);
        }
    }
}
