﻿namespace VFS.MI.Poland.Encryption
{
    public interface IPolandFileEncryption
    {
        public string EncryptFile(string xmlContent, string aurn,string MissionCode,string CountryCode , string VacCode);
    }
}
