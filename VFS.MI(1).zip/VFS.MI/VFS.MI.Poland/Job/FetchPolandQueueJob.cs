﻿using Amazon.SQS.Model;
using Microsoft.Extensions.Options;
using System.Text.Json;
using System.Xml.Serialization;
using VFS.Caching;
using VFS.MI.AWS.S3;
using VFS.MI.AWS.SQS;
using VFS.MI.Poland.Contract.V1.SQS;
using VFS.MI.Poland.DAL;
using VFS.MI.Poland.Encryption;
using VFS.MI.Poland.Options;
using VFS.MI.Poland.XMLGenerator;

namespace VFS.MI.Poland.Job
{
    public class FetchPolandQueueJob : BackgroundService
    {

        private ISQSHelper _sqsHelper;
        private int pauseTimeMinute = 2;
        private IXmlGenerator _xmlGenerator;
        private IPolandFileEncryption _polandEncryption;
        private IS3Helper _s3Helper;
        private IUtilitiesCache _utilitiesCache;
        private IDAL _dal;
        private ApplicationOptions _applicationOptions;

        public FetchPolandQueueJob(IUtilitiesCache utilitiesCache, ISQSHelper sqsHelper, IXmlGenerator xmlGenerator, IPolandFileEncryption polandEncryption, IS3Helper s3Helper, IDAL dal, IOptions<ApplicationOptions> applicationOptions)
        {
            _sqsHelper = sqsHelper;
            _xmlGenerator = xmlGenerator;
            _polandEncryption = polandEncryption;
            _s3Helper = s3Helper;
            _utilitiesCache = utilitiesCache;
            _dal = dal;
            _applicationOptions = applicationOptions.Value;


        }

        protected override Task ExecuteAsync(CancellationToken stoppingToken)
        {
            return Task.Factory.StartNew(async () =>
            {
                string queueUrl = _utilitiesCache.GetSqsUrl(_applicationOptions.ConnectionString, "POL", false);

                while (!stoppingToken.IsCancellationRequested)
                {
                    try
                    {
                        ReceiveMessageResponse messageResponse = await _sqsHelper.GetMessage(queueUrl, 0);
                        if (messageResponse.Messages.Any())
                        {
                            foreach (var message in messageResponse.Messages)
                            {
                                try
                                {

                                    if (!String.IsNullOrEmpty(message.Body))
                                    {
                                        BoltSqsData boltSqsData = JsonSerializer.Deserialize<BoltSqsData>(message.Body);
                                        XMLResponse xml = _xmlGenerator.GetPolandXML(boltSqsData);
                                        if (!xml.isError)
                                        {
                                            string encryptedFilPath = _polandEncryption.EncryptFile(xml.XML, boltSqsData.FormularNumber, boltSqsData.MissionCode,boltSqsData.CountryCode ,boltSqsData.VacCode);
                                            string s3Key = boltSqsData.MissionCode + "/" + boltSqsData.CountryCode + "/" + boltSqsData.VacCode + "/" + Path.GetFileName(encryptedFilPath);
                                            bool s3Result = await _s3Helper.UploadFile("mi-poland",
                                                s3Key,
                                                encryptedFilPath);

                                            if (s3Result)
                                            {
                                                _dal.UpdateS3Key(boltSqsData.FormularNumber, s3Key);
                                                File.Delete(encryptedFilPath);
                                                await _sqsHelper.DeleteMessage(queueUrl, message.ReceiptHandle, stoppingToken);
                                                //Call bolt API
                                            }
                                            else
                                            {

                                            }
                                        }
                                        else { 
                                            //Call bolt error API
                                        
                                        }

                                    }
                                }
                                catch (Exception e)
                                {
                                    int i = 0;
                                }
                            }

                            pauseTimeMinute = 2;
                            await Task.Delay(TimeSpan.FromMinutes(pauseTimeMinute), stoppingToken);
                        }
                        else
                        {
                            pauseTimeMinute = pauseTimeMinute + 2;
                            if (pauseTimeMinute > 10)
                            {
                                pauseTimeMinute = 10;
                            }
                            await Task.Delay(TimeSpan.FromMinutes(pauseTimeMinute), stoppingToken);
                        }

                    }
                    catch (OperationCanceledException)
                    {

                    }
                }
            }, stoppingToken);
        }

        public override async Task StopAsync(CancellationToken cancellationToken)
        {
            await Task.CompletedTask;
        }
    }
}
