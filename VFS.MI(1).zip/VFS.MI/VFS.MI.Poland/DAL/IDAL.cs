﻿namespace VFS.MI.Poland.DAL
{
    public interface IDAL
    {
        public string UpdateS3Key(string arn, string S3Key);
        public string GetEncryptionKey(string MissionCode, string CountryCode, string VacCode);
    }
}
