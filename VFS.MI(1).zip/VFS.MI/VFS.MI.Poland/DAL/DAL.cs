﻿using System.Data.SqlClient;
using System.Data;
using VFS.MI.Poland.XMLGenerator.POCO;
using VFS.MI.Poland.Options;
using Microsoft.Extensions.Options;

namespace VFS.MI.Poland.DAL
{
    public class DAL:IDAL
    {
        private ApplicationOptions _applicationOptions;
        string conStr = String.Empty;

        public DAL(IOptions<ApplicationOptions> applicationOptions)
        {
            _applicationOptions = applicationOptions.Value;
            conStr = _applicationOptions.ConnectionString;
        }

       

        public string UpdateS3Key(string arn,string S3Key)
        {

            try
            {
                using (SqlConnection con = new SqlConnection(conStr))
                {
                    SqlCommand cmd = new SqlCommand("proc_insert_S3_key", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@ARN", arn);
                    cmd.Parameters.AddWithValue("@S3Key", S3Key);
                    SqlParameter outputParam = cmd.Parameters.Add("@msgOutput", SqlDbType.NVarChar, 500);
                    outputParam.Direction = ParameterDirection.Output;
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();

                    return outputParam.ToString();
                }
            }
            catch (Exception e)
            {
                throw;
            }
        }

        public string GetEncryptionKey(string MissionCode, string CountryCode, string VacCode)
        {

            try
            {
                using (SqlConnection con = new SqlConnection(conStr))
                {
                    SqlCommand cmd = new SqlCommand("proc_get_encryption_key", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@MissionCode", MissionCode);
                    cmd.Parameters.AddWithValue("@CountryCode", CountryCode);
                    cmd.Parameters.AddWithValue("@VacCode", VacCode);
                    SqlParameter outputParam = cmd.Parameters.Add("@msgOutput", SqlDbType.NVarChar, 500);
                    outputParam.Direction = ParameterDirection.Output;
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    con.Open();
                    da.Fill(dt);
                    string encryptionKeyValue = Convert.ToString(dt.Rows[0][0]);
                    con.Close();

                    return encryptionKeyValue;
                }
            }
            catch (Exception e)
            {
                throw;
            }
        }
    }
}
