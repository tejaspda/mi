﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using VFS.Communicator.Biometrics.POCO;

namespace VFS.Communicator.Biometrics
{
    public interface IBiometricCommunicator
    {
        public Task<BiometricResponse> GetBiometricAndFacialAsync(string missionCode, string aurn, string BIOMETRIC_URL, string tokenKey);

        public Task<FastTrackBiometricResponse> GetFasttrackBiometricAsync(string missionCode, string aurn, string BIOMETRIC_URL, string tokenKey);

        public Task<BiometricResponse> GetFaciaImageAsync(string missionCode, string aurn, string BIOMETRIC_URL, string tokenKey);

        public Task<BiometricResponse> GetFingerprintsAsync(string missionCode, string aurn, string BIOMETRIC_URL, string tokenKey);

        public Task<BiometricPurgeResponse> PurgeBiometricAsync(string missionCode, string aurn, string BIOMETRIC_URL, string tokenKey);

    }
}
