﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VFS.Communicator.Biometrics.POCO
{
    public class BiometricPurgeRequest
    {
        public string aurn { get; set; }
        public string mission { get; set; }
        public string enrolDate { get; set; }
        public string acknowledgementCode { get; set; }
    }
}
