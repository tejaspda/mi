﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VFS.Communicator.Biometrics.POCO
{
    public class BiometricResponse
    {
        public string responseCode { get; set; }
        public string aurn { get; set; }
        public string mission { get; set; }
        public DateTime enrolDate { get; set; }
        public string guid { get; set; }
        public string data { get; set; }
        public string photo { get; set; }
        public string missionKey { get; set; }
    }
}
