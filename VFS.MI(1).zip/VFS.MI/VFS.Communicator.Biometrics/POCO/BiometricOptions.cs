﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VFS.Communicator.Biometrics.POCO
{
    public class BiometricOptions
    {
        public bool MockBiometric { get; set; }
        public string BiometricUrl { get; set; }
        public bool DisableSSLValidation { get; set; }
        public String UserName { get; set; }
        public String Password { get; set; }
        public bool BiometricExtraLog { get; set; }
    }
}
