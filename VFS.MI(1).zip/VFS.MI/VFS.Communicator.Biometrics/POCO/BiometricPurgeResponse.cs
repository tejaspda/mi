﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VFS.Communicator.Biometrics.POCO
{
    public class BiometricPurgeResponse
    {
        public string ResponseCode { get; set; }
        public string ResponseText { get; set; }
    }
}
