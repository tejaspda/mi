﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VFS.Communicator.Biometrics.POCO
{
    class BiometricRequest
    {
        public string aurn { get; set; }
        public string mission { get; set; }
        public string enrolDate { get; set; }
        public string biometricRequestType { get; set; }

    }
}
