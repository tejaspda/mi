﻿

using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using System.Text;
using VFS.Communicator.Biometrics.POCO;

namespace VFS.Communicator.Biometrics
{
    public class BiometricCommunicator : IBiometricCommunicator
    {
        private readonly HttpClient _httpClient;
        private String userName;
        private String password;
        private IMemoryCache _cache;

        public BiometricCommunicator(HttpClient httpClient, IOptions<BiometricOptions> options, IMemoryCache cache)
        {
            _httpClient = httpClient;
            userName = options.Value.UserName;
            password = options.Value.Password;
            _cache = cache;
        }

        public async Task<BiometricResponse> GetBiometricAndFacialAsync(string missionCode, string aurn,string BIOMETRIC_URL,string tokenKey)
        {
            _httpClient.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", await GetTokenFromCacheAsync(tokenKey, BIOMETRIC_URL));

            BiometricRequest biometricRequest = new BiometricRequest();
            biometricRequest.aurn = aurn;
            biometricRequest.enrolDate = "LATEST";
            biometricRequest.biometricRequestType = "DATA_PACKET_AND_PHOTOGRAPH";
            biometricRequest.mission = "FI";

            var json = JsonConvert.SerializeObject(biometricRequest);
            var stringContent = new StringContent(json, UnicodeEncoding.UTF8, "application/json");
            var response = await _httpClient.PostAsync($"{BIOMETRIC_URL}/api/GetBiometricDetails", stringContent);

            if (response.StatusCode == System.Net.HttpStatusCode.Unauthorized) {
                await GetToken(tokenKey,BIOMETRIC_URL);
                return await GetBiometricAndFacialAsync(missionCode, aurn,BIOMETRIC_URL,tokenKey);
            }

            string responseString = await response.Content.ReadAsStringAsync();

            if (responseString != null)
            {
                return JsonConvert.DeserializeObject<BiometricResponse>(responseString);
            }
            else
            {
                BiometricResponse biometricResponse = new BiometricResponse();
                biometricResponse.responseCode = "Failure";
                return biometricResponse;
            }
        }

        public async Task<BiometricResponse> GetFaciaImageAsync(string missionCode, string aurn, string BIOMETRIC_URL, string tokenKey)
        {
            _httpClient.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", await GetTokenFromCacheAsync(tokenKey, BIOMETRIC_URL));

            BiometricRequest biometricRequest = new BiometricRequest();
            biometricRequest.aurn = aurn;
            biometricRequest.enrolDate = "LATEST";
            biometricRequest.biometricRequestType = "PHOTOGRAPH";
            biometricRequest.mission = "FI";
            var json = JsonConvert.SerializeObject(biometricRequest);
            var stringContent = new StringContent(json, UnicodeEncoding.UTF8, "application/json");
            var response = await _httpClient.PostAsync($"{BIOMETRIC_URL}/api/GetBiometricDetails", stringContent);
            if (response.StatusCode == System.Net.HttpStatusCode.Unauthorized)
            {
                await GetToken(tokenKey,BIOMETRIC_URL);
                return await GetFaciaImageAsync(missionCode, aurn,BIOMETRIC_URL,tokenKey);
            }
            string responseString = await response.Content.ReadAsStringAsync();
            if (responseString != null)
            {
                return JsonConvert.DeserializeObject<BiometricResponse>(responseString);
            }
            else {
                BiometricResponse biometricResponse = new BiometricResponse();
                biometricResponse.responseCode = "Failure";
                return biometricResponse;
            }
        }

        public async Task<BiometricResponse> GetFingerprintsAsync(string missionCode, string aurn,string BIOMETRIC_URL,string tokenKey)
        {
            BiometricTokenResponse biometricTokenResponse = await GetToken(tokenKey,BIOMETRIC_URL);
            _httpClient.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", await GetTokenFromCacheAsync(tokenKey, BIOMETRIC_URL));

            BiometricRequest biometricRequest = new BiometricRequest();
            biometricRequest.aurn = aurn;
            biometricRequest.enrolDate = "LATEST";
            biometricRequest.biometricRequestType = "DATA_PACKET";
            biometricRequest.mission = "FI";
            var json = JsonConvert.SerializeObject(biometricRequest);
            var stringContent = new StringContent(json, UnicodeEncoding.UTF8, "application/json");
            var response = await _httpClient.PostAsync($"{BIOMETRIC_URL}/api/GetBiometricDetails", stringContent);
            if (response.StatusCode == System.Net.HttpStatusCode.Unauthorized)
            {
                await GetToken(tokenKey,BIOMETRIC_URL);
                return await GetFingerprintsAsync(missionCode, aurn,BIOMETRIC_URL,tokenKey);
            }
            string responseString = await response.Content.ReadAsStringAsync();
            if (responseString != null)
            {
                return JsonConvert.DeserializeObject<BiometricResponse>(responseString);
            }
            else
            {
                BiometricResponse biometricResponse = new BiometricResponse();
                biometricResponse.responseCode = "Failure";
                return biometricResponse;
            }
        }

        public async Task<BiometricPurgeResponse> PurgeBiometricAsync(string missionCode, string aurn, string BIOMETRIC_URL, string tokenKey)
        {
            BiometricTokenResponse biometricTokenResponse = await GetToken(tokenKey,BIOMETRIC_URL);

            //Set Header
            _httpClient.DefaultRequestHeaders.Authorization =new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", await GetTokenFromCacheAsync(tokenKey, BIOMETRIC_URL));

            BiometricPurgeRequest biometricRequest = new BiometricPurgeRequest();
            biometricRequest.aurn = aurn;
            biometricRequest.enrolDate = "LATEST";
            biometricRequest.acknowledgementCode = "ACK_OK";
            biometricRequest.mission = "FI";
            var json = JsonConvert.SerializeObject(biometricRequest);

            var stringContent = new StringContent(json, UnicodeEncoding.UTF8, "application/json");
            var response = await _httpClient.PostAsync($"{BIOMETRIC_URL}/api/GetBiometricDetails", stringContent);
            if (response.StatusCode == System.Net.HttpStatusCode.Unauthorized)
            {
                await GetToken(tokenKey, BIOMETRIC_URL);
                return await PurgeBiometricAsync(missionCode, aurn,BIOMETRIC_URL,tokenKey);
            }
            string responseString = await response.Content.ReadAsStringAsync();

            if (responseString != null)
            {
                return JsonConvert.DeserializeObject<BiometricPurgeResponse>(responseString);
            }
            else
            {
                BiometricPurgeResponse biometricResponse = new BiometricPurgeResponse();
                biometricResponse.ResponseCode = "Failure";
                return biometricResponse;
            }

        }

        private async Task<BiometricTokenResponse> GetToken(string key,string BIOMETRIC_URL) {

            BiometricTokenResponse biometricTokenResponse = new BiometricTokenResponse();

            var nvc = new List<KeyValuePair<string, string>>();
            nvc.Add(new KeyValuePair<string, string>("Username", userName));
            nvc.Add(new KeyValuePair<string, string>("Password", password));
            nvc.Add(new KeyValuePair<string, string>("grant_type", "password"));
            var client = new HttpClient();
            var req = new HttpRequestMessage(HttpMethod.Post, $"{BIOMETRIC_URL}/Token") { Content = new FormUrlEncodedContent(nvc) };
            var res = await client.SendAsync(req);
            string responseString = await res.Content.ReadAsStringAsync();

            biometricTokenResponse = JsonConvert.DeserializeObject<BiometricTokenResponse>(responseString);
            _cache.Set(key, biometricTokenResponse.access_token);
            return biometricTokenResponse;
           
        }

        private async Task<string> GetTokenFromCacheAsync(string key,string BIOMETRIC_URL)
        {
            String token = null;

            if (!_cache.TryGetValue(key, out token))
            {
                BiometricTokenResponse biometricResponse = await GetToken(key,BIOMETRIC_URL);
                token = biometricResponse.access_token;
            }
            return token;
        }

        public async Task<FastTrackBiometricResponse> GetFasttrackBiometricAsync(string missionCode, string aurn, string BIOMETRIC_URL, string tokenKey)
        {
            _httpClient.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", await GetTokenFromCacheAsync(tokenKey, BIOMETRIC_URL));

            BiometricRequest biometricRequest = new BiometricRequest();
            biometricRequest.aurn = aurn;
            biometricRequest.enrolDate = "LATEST";
            biometricRequest.biometricRequestType = "DATA_PACKET_AND_PHOTOGRAPH";
            biometricRequest.mission = "FI";



            var json = JsonConvert.SerializeObject(biometricRequest);
            var stringContent = new StringContent(json, UnicodeEncoding.UTF8, "application/json");
            var response = await _httpClient.PostAsync($"{BIOMETRIC_URL}/api/GetFinlandBioPackages", stringContent);

            if (response.StatusCode == System.Net.HttpStatusCode.Unauthorized)
            {
                await GetToken(tokenKey, BIOMETRIC_URL);
                return await GetFasttrackBiometricAsync(missionCode, aurn, BIOMETRIC_URL, tokenKey);
            }

            string responseString = await response.Content.ReadAsStringAsync();
            if (responseString != null)
            {
                return JsonConvert.DeserializeObject<FastTrackBiometricResponse>(responseString);
            }
            else
            {
                FastTrackBiometricResponse biometricResponse = new FastTrackBiometricResponse();
                biometricResponse.responseCode = "Failure";
                return biometricResponse;
            }
        }
    }

}
