﻿using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Text;
using VFS.Communicator.Biometrics;
using VFS.Communicator.Biometrics.POCO;

namespace VFS.Communicator.Bolt.Extensions
{
    public static class IServiceCollectionExtensions
    {
        public static IHttpClientBuilder AddBiometrics(this IServiceCollection collection, Action<BiometricOptions> setupAction)
        {
            if (collection == null) throw new ArgumentNullException(nameof(collection));
            if (setupAction == null) throw new ArgumentNullException(nameof(setupAction));

            collection.Configure(setupAction);

            BiometricOptions options = new BiometricOptions();
            setupAction(options);

            IHttpClientBuilder httpClientBuilder = null;

            if (options.MockBiometric)
            {
                httpClientBuilder = collection.AddHttpClient<IBiometricCommunicator, BiometricCommunicatorMock>();
            }
            else
            {
                httpClientBuilder = collection.AddHttpClient<IBiometricCommunicator, BiometricCommunicator>();
            }

/*            if (options.DisableSSLValidation)
            {
              //  httpClientBuilder.ConfigurePrimaryHttpMessageHandler(CommunicatorHelper.DisableSSLValidation);
            }*/

            return httpClientBuilder;
        }
    }
}
