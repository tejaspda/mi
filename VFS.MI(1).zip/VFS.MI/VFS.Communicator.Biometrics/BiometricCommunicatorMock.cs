﻿using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using VFS.Communicator.Biometrics.POCO;

namespace VFS.Communicator.Biometrics
{
    public class BiometricCommunicatorMock : IBiometricCommunicator
    {
        private readonly HttpClient _httpClient;

        private readonly string BIOMETRIC_URL;

        public BiometricCommunicatorMock(HttpClient httpClient, IOptions<BiometricOptions> options)
        {
            _httpClient = httpClient;

            BIOMETRIC_URL = "";
        }
        public async Task<BiometricResponse> GetBiometricAndFacialAsync(string missionCode, string aurn, string BIOMETRIC_URL, string tokenKey)
        {
            string jsonString = await System.IO.File.ReadAllTextAsync(@"MockData/Biometric.json");

            jsonString = jsonString.Replace("##aurn##", aurn);

            return JsonConvert.DeserializeObject<BiometricResponse>(jsonString);
        }

        public async Task<BiometricResponse> GetFaciaImageAsync(string missionCode, string aurn, string BIOMETRIC_URL, string tokenKey)
        {
            string jsonString = await System.IO.File.ReadAllTextAsync(@"MockData/Biometric.json");

            jsonString = jsonString.Replace("##aurn##", aurn);

            return JsonConvert.DeserializeObject<BiometricResponse>(jsonString);
        }

        public async Task<FastTrackBiometricResponse> GetFasttrackBiometricAsync(string missionCode, string aurn, string BIOMETRIC_URL, string tokenKey)
        {
            string jsonString = await System.IO.File.ReadAllTextAsync(@"MockData/Biometric.json");

            jsonString = jsonString.Replace("##aurn##", aurn);

            return JsonConvert.DeserializeObject<FastTrackBiometricResponse>(jsonString);
        }

        public async Task<BiometricResponse> GetFingerprintsAsync(string missionCode, string aurn,string BIOMETRIC_URL, string tokenKey)
        {
            string jsonString = await System.IO.File.ReadAllTextAsync(@"MockData/Biometric.json");

            jsonString = jsonString.Replace("##aurn##", aurn);

            return JsonConvert.DeserializeObject<BiometricResponse>(jsonString);
        }

        public Task<BiometricTokenResponse> GetToken(string key, string BIOMETRIC_URL)
        {
            throw new NotImplementedException();
        }

        public async Task<BiometricPurgeResponse> PurgeBiometricAsync(string missionCode, string aurn, string BIOMETRIC_URL, string tokenKey)
        {
            string jsonString = await System.IO.File.ReadAllTextAsync(@"MockData/Biometric.json");

            jsonString = jsonString.Replace("##aurn##", aurn);

            return JsonConvert.DeserializeObject<BiometricPurgeResponse>(jsonString);
        }
    }
}
